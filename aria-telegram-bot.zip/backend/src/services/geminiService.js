const { GoogleGenerativeAI } = require('@google/generative-ai');
const { z } = require('zod');
const chrono = require('chrono-node');
const dayjs = require('dayjs');
require('dayjs/locale/pt-br');
dayjs.locale('pt-br');

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// ─── Schemas Zod para validar o retorno do Gemini ───────────────────────────
const IntentSchema = z.discriminatedUnion('intent', [
  z.object({
    intent: z.literal('create_event'),
    data: z.object({
      title:       z.string().min(1),
      date:        z.string().optional().nullable(),
      time:        z.string().optional().nullable(),
      end_time:    z.string().optional().nullable(),
      location:    z.string().optional().nullable(),
      description: z.string().optional().nullable(),
      reminder_min: z.number().optional().default(30),
    }),
    reply: z.string(),
  }),
  z.object({
    intent: z.literal('create_task'),
    data: z.object({
      title:       z.string().min(1),
      description: z.string().optional().nullable(),
      due_date:    z.string().optional().nullable(),
      due_time:    z.string().optional().nullable(),
      priority:    z.enum(['low','medium','high']).default('medium'),
      tags:        z.array(z.string()).optional().default([]),
    }),
    reply: z.string(),
  }),
  z.object({
    intent: z.literal('create_note'),
    data: z.object({
      title:   z.string().optional().nullable(),
      content: z.string(),
      tags:    z.array(z.string()).optional().default([]),
    }),
    reply: z.string(),
  }),
  z.object({
    intent: z.literal('health_log'),
    data: z.object({
      type:  z.enum(['water','exercise','sleep','medication']),
      value: z.number().optional().nullable(),
      unit:  z.string().optional().nullable(),
      notes: z.string().optional().nullable(),
    }),
    reply: z.string(),
  }),
  z.object({
    intent: z.literal('finance_log'),
    data: z.object({
      title:    z.string().min(1),
      amount:   z.number().positive(),
      type:     z.enum(['income','expense']),
      category: z.string().optional().default('Geral'),
      due_at:   z.string().optional().nullable(),
    }),
    reply: z.string(),
  }),
  z.object({
    intent: z.literal('query'),
    data: z.object({
      entity: z.string(),
      filter: z.string().optional().nullable(),
    }),
    reply: z.string(),
  }),
  z.object({
    intent: z.literal('pending_content'),
    data: z.object({
      context: z.string(),   // 'note' | 'task' etc
      prompt:  z.string(),   // o que perguntar ao usuário
    }),
    reply: z.string(),
  }),
  z.object({
    intent: z.literal('chitchat'),
    data:   z.object({}).passthrough(),
    reply:  z.string(),
  }),
]);

// ─── System prompt ───────────────────────────────────────────────────────────
function buildSystemPrompt() {
  const now = dayjs();
  const today = now.format('dddd, D [de] MMMM [de] YYYY');
  const time  = now.format('HH:mm');
  const dow   = now.day(); // 0=dom, 6=sab

  // Calcula próximas datas úteis para o prompt
  const tomorrow    = now.add(1, 'day').format('YYYY-MM-DD');
  const nextMonday  = now.add((8 - dow) % 7 || 7, 'day').format('YYYY-MM-DD');
  const thisFriday  = now.add((5 - dow + 7) % 7, 'day').format('YYYY-MM-DD');

  return `Você é ARIA, uma assistente pessoal inteligente. Responda SEMPRE em português brasileiro.

DATA E HORA ATUAL: ${today}, ${time}
AMANHÃ: ${tomorrow}
PRÓXIMA SEXTA: ${thisFriday}
PRÓXIMA SEGUNDA: ${nextMonday}

REGRAS:
- Responda SOMENTE com JSON válido, sem markdown, sem explicações fora do JSON
- Seja direta e simpática no campo "reply" — estilo Telegram, com emojis
- Nunca invente dados que não foram fornecidos pelo usuário
- Para datas relativas ("amanhã", "sexta", "semana que vem") use as datas acima como referência
- Formato de data: YYYY-MM-DD | Formato de hora: HH:MM (24h)

INTENÇÕES DISPONÍVEIS:

1. create_event — evento, compromisso, prova, reunião, consulta
   Exemplos: "agende prova dia 10 às 18h", "reunião amanhã 14h", "consulta médica sexta"

2. create_task — tarefa, lembrete de ação, afazer
   Exemplos: "me lembra de pagar conta sexta", "tarefa: revisar relatório até amanhã"

3. create_note — anotar, registrar texto, salvar informação
   Exemplos: "anote que...", "faça a seguinte anotação", "salve esse conteúdo"
   Se o usuário pedir para anotar MAS não fornecer o conteúdo ainda:
   → use intent "pending_content" com context "note"

4. health_log — saúde, água, exercício, remédio, sono
   Exemplos: "tomei omeprazol", "bebi 500ml de água", "fiz 30min de caminhada", "dormi 7h"

5. finance_log — gasto, receita, despesa, pagamento
   Exemplos: "gastei R$50 no almoço", "recebi salário de R$5000", "paguei R$200 de internet"

6. query — consultar, listar, mostrar dados existentes
   Exemplos: "quais meus eventos hoje?", "mostre tarefas pendentes", "minhas últimas notas"

7. pending_content — quando o usuário quer criar algo mas FALTA o conteúdo principal
   Use quando: "quero fazer uma anotação" (sem dizer o quê), "crie uma tarefa" (sem dizer qual)

8. chitchat — conversa, saudação, perguntas gerais, dúvidas

EXEMPLOS COMPLETOS:

Input: "Aria agende para o dia 10 de março a noite as 18:00 prova de arquitetura de software"
Output: {"intent":"create_event","data":{"title":"Prova de Arquitetura de Software","date":"2026-03-10","time":"18:00","reminder_min":60},"reply":"✅ Prova de Arquitetura de Software agendada para 10/03 às 18h! 🔔 Lembrete 1h antes. Boa sorte! 📚"}

Input: "aria faça a seguinte anotação da aula de notação hexadecimal"
Output: {"intent":"pending_content","data":{"context":"note","prompt":"title":"Aula — Notação Hexadecimal","tags":["aula","hexadecimal"]},"reply":"📝 Pode mandar o conteúdo da anotação! Vou salvar tudo."}

Input: "me lembra de pagar conta de luz na sexta"
Output: {"intent":"create_task","data":{"title":"Pagar conta de luz","due_date":"${thisFriday}","due_time":"09:00","priority":"high","tags":["financeiro","contas"]},"reply":"✅ Lembrete criado! Pagar conta de luz na sexta (${dayjs(thisFriday).format('DD/MM')}). 💡"}

Input: "tomei omeprazol agora"
Output: {"intent":"health_log","data":{"type":"medication","value":1,"unit":"dose","notes":"Omeprazol"},"reply":"💊 Omeprazol registrado! Cuidando da saúde. ✅"}

Input: "gastei 45 reais no almoço"
Output: {"intent":"finance_log","data":{"title":"Almoço","amount":45,"type":"expense","category":"Alimentação"},"reply":"💸 Gasto de R$ 45,00 no almoço registrado!"}`;
}

// ─── Histórico por sessão (em memória, TTL implícito por restart) ─────────────
const sessions = new Map();

function getHistory(sessionId) {
  if (!sessions.has(sessionId)) sessions.set(sessionId, []);
  return sessions.get(sessionId);
}

function addToHistory(sessionId, role, text) {
  const hist = getHistory(sessionId);
  hist.push({ role, parts: [{ text }] });
  // Mantém só as últimas 8 trocas para não explodir o contexto
  if (hist.length > 16) hist.splice(0, 2);
}

// ─── Parse robusto do JSON retornado ─────────────────────────────────────────
function parseGeminiResponse(raw) {
  // Remove markdown fences se houver
  let clean = raw.trim().replace(/^```json\s*/i, '').replace(/\s*```$/, '').trim();

  // Às vezes o Gemini coloca texto antes do JSON
  const jsonStart = clean.indexOf('{');
  if (jsonStart > 0) clean = clean.slice(jsonStart);

  const parsed = JSON.parse(clean);
  return IntentSchema.parse(parsed);
}

// ─── Chat principal com retry ─────────────────────────────────────────────────
async function chat(userMessage, sessionId = 'default', retries = 2) {
  const model = genAI.getGenerativeModel({
    model: process.env.GEMINI_MODEL || 'gemini-2.0-flash',
    generationConfig: {
      temperature: 0.3,       // Mais determinístico
      topP: 0.8,
      maxOutputTokens: 512,
    },
  });

  const systemPrompt = buildSystemPrompt();
  const history = getHistory(sessionId);

  const contents = [
    // Âncora do sistema como primeiro par de mensagens
    { role: 'user',  parts: [{ text: systemPrompt + '\n\nPrimeira mensagem:' }] },
    { role: 'model', parts: [{ text: '{"intent":"chitchat","data":{},"reply":"Entendido! Sou ARIA, pronta para ajudar."}' }] },
    ...history,
    { role: 'user',  parts: [{ text: userMessage }] },
  ];

  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const result = await model.generateContent({ contents });
      const raw = result.response.text();
      const parsed = parseGeminiResponse(raw);

      // Salva no histórico só se deu certo
      addToHistory(sessionId, 'user', userMessage);
      addToHistory(sessionId, 'model', JSON.stringify(parsed));

      return parsed;
    } catch (err) {
      const isLast = attempt === retries;
      console.error(`❌ Gemini attempt ${attempt + 1} failed:`, err.message);
      if (isLast) {
        // Fallback: retorna chitchat com mensagem de erro amigável
        return {
          intent: 'chitchat',
          data: {},
          reply: '🤔 Não consegui interpretar sua mensagem. Pode reformular? Tente ser mais específico, ex: "agende reunião amanhã às 14h".',
        };
      }
      // Espera antes de retry (exponential backoff)
      await new Promise(r => setTimeout(r, 800 * (attempt + 1)));
    }
  }
}

// ─── Parse de data robusto com chrono-node como fallback ─────────────────────
function parseDate(dateStr, timeStr) {
  if (!dateStr) return null;

  // Tenta direto se já vier no formato YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
    const [h, m] = (timeStr || '09:00').split(':').map(Number);
    const d = new Date(dateStr + 'T00:00:00');
    if (isNaN(d.getTime())) return null;
    d.setHours(h || 9, m || 0, 0, 0);
    return d;
  }

  // Fallback: chrono-node para linguagem natural em PT
  const parsed = chrono.pt.parseDate(`${dateStr} ${timeStr || ''}`.trim());
  return parsed || null;
}

// ─── Resumo diário ────────────────────────────────────────────────────────────
async function generateDailySummary({ events, tasks, weather, bills }) {
  const model = genAI.getGenerativeModel({
    model: process.env.GEMINI_MODEL || 'gemini-2.0-flash',
    generationConfig: { temperature: 0.7, maxOutputTokens: 300 },
  });

  const today = dayjs().format('dddd, D [de] MMMM');

  const prompt = `Crie um resumo matinal curto (máx 5 linhas) em português, estilo Telegram com emojis.
Hoje é ${today}.
Eventos: ${events.length > 0 ? events.map(e => `${dayjs(e.start_at).format('HH:mm')} ${e.title}`).join(', ') : 'nenhum'}
Tarefas pendentes: ${tasks.length > 0 ? tasks.map(t => t.title).join(', ') : 'nenhuma'}
Clima: ${weather ? `${weather.temp}°C, ${weather.description}` : 'não disponível'}
Contas: ${bills.length > 0 ? bills.map(b => `${b.title} R$${b.amount}`).join(', ') : 'nenhuma'}
Termine com uma frase motivacional curta.`;

  try {
    const result = await model.generateContent(prompt);
    return result.response.text();
  } catch {
    return `☀️ Bom dia! Hoje é ${today}.\n📅 ${events.length} evento(s) | ✅ ${tasks.length} tarefa(s) pendente(s)\nTenha um ótimo dia! 🚀`;
  }
}

module.exports = { chat, parseDate, generateDailySummary };
