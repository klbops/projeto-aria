const { GoogleGenerativeAI } = require('@google/generative-ai');
const db = require('../../config/database');

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// ─── System prompt da ARIA ───────────────────────────────────────────────────
const SYSTEM_PROMPT = `Você é ARIA, uma assistente pessoal inteligente em português brasileiro.
Você integra com: Google Calendar, Google Tasks, Telegram, e gerencia eventos, tarefas, notas, saúde e finanças.

REGRAS DE RESPOSTA:
- Responda SEMPRE em português brasileiro
- Seja direta, simpática e concisa — estilo Telegram
- Use emojis com moderação para clareza
- NUNCA invente dados — sempre confirme ações realizadas

FORMATO DE INTENÇÃO:
Quando o usuário pede algo, você deve retornar um JSON estruturado assim:
{
  "intent": "create_event|create_task|create_note|health_log|finance_log|query|chitchat",
  "data": { ... campos específicos ... },
  "reply": "Mensagem amigável confirmando a ação ou respondendo"
}

INTENÇÕES DISPONÍVEIS:

1. create_event → criar evento/compromisso/prova/reunião
   data: { title, date, time, end_time?, location?, description?, reminder_min? }
   Exemplos: "agende prova de arquitetura dia 10 às 18h", "reunião amanhã 14h"

2. create_task → criar tarefa/lembrete de ação
   data: { title, due_date?, due_time?, priority?, tags?, description? }
   Exemplos: "me lembra de pagar a conta de luz sexta", "tarefa: comprar remédio"

3. create_note → salvar anotação/nota/conteúdo
   data: { title?, content, tags? }
   Exemplos: "anote: notação hexadecimal usa base 16...", "anotação da aula de hoje"

4. health_log → registrar saúde (água, exercício, remédio, sono)
   data: { type, value?, unit?, notes? }
   type: water|exercise|medication|sleep

5. finance_log → registrar gasto/receita
   data: { title, amount, type (income|expense), category?, due_at? }

6. query → buscar/listar dados existentes
   data: { entity, filter? }

7. chitchat → conversa normal, saudação, dúvida geral
   data: {}

DATAS E HORÁRIOS:
- Hoje é: {TODAY}
- Interprete "amanhã", "semana que vem", "próxima sexta", "dia 10 de março" corretamente
- Formato de saída para datas: YYYY-MM-DD  |  horas: HH:MM

EXEMPLOS DE PARSING:
Usuário: "Aria agende para o dia 10 de março a noite as 18:00 prova de arquitetura de software"
→ { "intent":"create_event", "data":{"title":"Prova de Arquitetura de Software","date":"2026-03-10","time":"18:00","reminder_min":60}, "reply":"✅ Prova de Arquitetura de Software agendada para 10/03 às 18h! Lembrete 1h antes. 📚" }

Usuário: "aria faça a seguinte anotação da aula de notação hexadecimal"
→ { "intent":"create_note", "data":{"title":"Aula — Notação Hexadecimal","content":"[conteúdo pendente — aguardando texto do usuário]","tags":["aula","hexadecimal","programação"]}, "reply":"📝 Pronto! Me mande o conteúdo da anotação que vou salvar agora." }

Usuário: "me lembra de pagar conta de luz na sexta"
→ { "intent":"create_task", "data":{"title":"Pagar conta de luz","due_date":"2026-03-07","priority":"high","tags":["financeiro","contas"]}, "reply":"✅ Lembrete criado! Pagar conta de luz na sexta (07/03). 💡" }

Responda SOMENTE com o JSON válido, sem markdown, sem explicações extras.`;

// ─── Histórico em memória (por sessão) ──────────────────────────────────────
const sessions = new Map();

function getSession(sessionId) {
  if (!sessions.has(sessionId)) sessions.set(sessionId, []);
  return sessions.get(sessionId);
}

// ─── Chat principal ──────────────────────────────────────────────────────────
async function chat(userMessage, sessionId = 'default') {
  const model = genAI.getGenerativeModel({ model: process.env.GEMINI_MODEL || 'gemini-2.0-flash' });

  const today = new Date().toLocaleDateString('pt-BR', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
  });

  const systemWithDate = SYSTEM_PROMPT.replace('{TODAY}', today);
  const history = getSession(sessionId);

  // Contexto com histórico para conversas multi-turno
  const messages = [
    { role: 'user', parts: [{ text: systemWithDate + '\n\nPrimeira mensagem do usuário a seguir.' }] },
    { role: 'model', parts: [{ text: '{"intent":"chitchat","data":{},"reply":"Entendido! Sou ARIA, pronta para ajudar."}' }] },
    ...history.slice(-10), // últimas 5 trocas
    { role: 'user', parts: [{ text: userMessage }] }
  ];

  const result = await model.generateContent({ contents: messages });
  const raw = result.response.text().trim();

  // Salva no histórico
  history.push({ role: 'user', parts: [{ text: userMessage }] });
  history.push({ role: 'model', parts: [{ text: raw }] });

  // Parse JSON
  try {
    const clean = raw.replace(/```json|```/g, '').trim();
    return JSON.parse(clean);
  } catch {
    return { intent: 'chitchat', data: {}, reply: raw };
  }
}

// ─── Resumo diário inteligente ───────────────────────────────────────────────
async function generateDailySummary(data) {
  const model = genAI.getGenerativeModel({ model: process.env.GEMINI_MODEL || 'gemini-2.0-flash' });

  const prompt = `Você é ARIA. Crie um resumo matinal em português, estilo mensagem Telegram, com emojis.
  Use esses dados:
  - Eventos hoje: ${JSON.stringify(data.events)}
  - Tarefas pendentes: ${JSON.stringify(data.tasks)}
  - Clima: ${JSON.stringify(data.weather)}
  - Contas a pagar esta semana: ${JSON.stringify(data.bills)}
  
  Formato: 3-5 linhas, direto, útil, motivador. Termine com uma dica do dia.`;

  const result = await model.generateContent(prompt);
  return result.response.text();
}

// ─── Busca semântica em notas ────────────────────────────────────────────────
async function semanticSearch(query, notes) {
  const model = genAI.getGenerativeModel({ model: process.env.GEMINI_MODEL || 'gemini-2.0-flash' });

  const prompt = `Dado o array de notas abaixo, retorne os IDs das notas mais relevantes para a busca "${query}".
  Retorne apenas um array JSON de IDs, ex: [1, 3, 5].
  Notas: ${JSON.stringify(notes.map(n => ({ id: n.id, title: n.title, content: n.content.substring(0, 200) })))}`;

  const result = await model.generateContent(prompt);
  try {
    const clean = result.response.text().replace(/```json|```/g, '').trim();
    return JSON.parse(clean);
  } catch {
    return [];
  }
}

module.exports = { chat, generateDailySummary, semanticSearch };
