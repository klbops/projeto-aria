const TelegramBot = require('node-telegram-bot-api');
const geminiService = require('./geminiService');
const eventService = require('./eventService');
const taskService = require('./taskService');
const noteService = require('./noteService');
const healthService = require('./healthService');
const financeService = require('./financeService');

let bot = null;

// ── Estado para conversas multi-turno (espera de conteúdo extra) ─────────────
const pendingContext = new Map();

async function init() {
  if (!process.env.TELEGRAM_BOT_TOKEN) {
    throw new Error('TELEGRAM_BOT_TOKEN não definido');
  }

  // Polling mode para desenvolvimento; webhook para produção
  const mode = process.env.NODE_ENV === 'production' ? false : true;
  bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN, { polling: mode });

  bot.on('message', handleMessage);
  bot.on('polling_error', (err) => console.error('Telegram polling error:', err.message));

  console.log(`✅ Bot Telegram no modo: ${mode ? 'polling' : 'webhook'}`);
  return bot;
}

// ── Handler principal de mensagens ───────────────────────────────────────────
async function handleMessage(msg) {
  const chatId = msg.chat.id.toString();
  const text = msg.text?.trim();

  if (!text) return;

  // Segurança: apenas o chat autorizado (se configurado)
  const allowedId = process.env.TELEGRAM_CHAT_ID;
  if (allowedId && chatId !== allowedId) {
    return bot.sendMessage(chatId, '⛔ Acesso não autorizado.');
  }

  try {
    // Mostra "digitando..."
    await bot.sendChatAction(chatId, 'typing');

    // Verifica se está esperando conteúdo complementar
    const pending = pendingContext.get(chatId);
    if (pending) {
      pendingContext.delete(chatId);
      return handlePendingContent(chatId, text, pending);
    }

    // Comandos especiais
    if (text.startsWith('/')) {
      return handleCommand(chatId, text);
    }

    // Processa com Gemini
    const result = await geminiService.chat(text, chatId);
    await processIntent(chatId, result, text);

  } catch (err) {
    console.error('❌ Erro no handleMessage:', err);
    await bot.sendMessage(chatId, '❌ Ops, algo deu errado. Tente novamente!');
  }
}

// ── Processa a intenção retornada pelo Gemini ─────────────────────────────────
async function processIntent(chatId, result, originalText) {
  const { intent, data, reply } = result;

  switch (intent) {

    case 'create_event': {
      const event = await eventService.create({
        title: data.title,
        description: data.description || '',
        start_at: buildDateTime(data.date, data.time),
        end_at: data.end_time ? buildDateTime(data.date, data.end_time) : null,
        location: data.location || null,
        reminder_min: data.reminder_min || 30,
      });
      const formatted = formatDate(event.start_at);
      await send(chatId,
        `${reply}\n\n` +
        `📅 *${event.title}*\n` +
        `📆 ${formatted}\n` +
        `${event.location ? '📍 ' + event.location + '\n' : ''}` +
        `🔔 Lembrete: ${event.reminder_min} min antes`
      );
      break;
    }

    case 'create_task': {
      const task = await taskService.create({
        title: data.title,
        description: data.description || '',
        due_at: data.due_date ? buildDateTime(data.due_date, data.due_time || '09:00') : null,
        priority: data.priority || 'medium',
        tags: data.tags || [],
      });
      await send(chatId,
        `${reply}\n\n` +
        `✅ *${task.title}*\n` +
        `${task.due_at ? '📅 Prazo: ' + formatDate(task.due_at) + '\n' : ''}` +
        `🏷️ Prioridade: ${priorityLabel(task.priority)}`
      );
      break;
    }

    case 'create_note': {
      // Se o conteúdo está pendente (usuário disse para anotar mas não deu o texto)
      if (data.content && data.content.includes('[conteúdo pendente')) {
        pendingContext.set(chatId, { type: 'note', noteData: data });
        await send(chatId, reply);
      } else {
        const note = await noteService.create({
          title: data.title || null,
          content: data.content || originalText,
          tags: data.tags || [],
        });
        await send(chatId,
          `${reply}\n\n` +
          `📝 *${note.title || 'Nota'}*\n` +
          `🏷️ Tags: ${(note.tags || []).join(', ') || '—'}`
        );
      }
      break;
    }

    case 'health_log': {
      await healthService.log({
        type: data.type,
        value: data.value,
        unit: data.unit,
        notes: data.notes,
      });
      await send(chatId, reply);
      break;
    }

    case 'finance_log': {
      await financeService.create({
        title: data.title,
        amount: parseFloat(data.amount),
        type: data.type,
        category: data.category || 'Geral',
        due_at: data.due_at ? new Date(data.due_at) : null,
      });
      await send(chatId, reply);
      break;
    }

    case 'query': {
      const queryReply = await handleQuery(data);
      await send(chatId, queryReply);
      break;
    }

    default:
      await send(chatId, reply || '🤔 Não entendi. Pode reformular?');
  }
}

// ── Aguarda conteúdo complementar (ex: texto da anotação) ────────────────────
async function handlePendingContent(chatId, text, pending) {
  if (pending.type === 'note') {
    const d = pending.noteData;
    const note = await noteService.create({
      title: d.title || null,
      content: text,
      tags: d.tags || [],
    });
    await send(chatId,
      `📝 Anotação salva!\n\n` +
      `*${note.title || 'Nota'}*\n` +
      `🏷️ Tags: ${(note.tags || []).join(', ') || '—'}\n` +
      `✅ Conteúdo registrado com sucesso.`
    );
  }
}

// ── Queries (listar eventos, tarefas, etc.) ───────────────────────────────────
async function handleQuery(data) {
  const entity = data.entity || '';
  if (entity.includes('event') || entity.includes('agenda')) {
    const events = await eventService.listUpcoming(5);
    if (!events.length) return '📅 Nenhum evento próximo encontrado.';
    return '📅 *Próximos eventos:*\n\n' + events.map(e =>
      `• *${e.title}* — ${formatDate(e.start_at)}`
    ).join('\n');
  }
  if (entity.includes('task') || entity.includes('tarefa')) {
    const tasks = await taskService.listPending(5);
    if (!tasks.length) return '✅ Nenhuma tarefa pendente!';
    return '✅ *Tarefas pendentes:*\n\n' + tasks.map(t =>
      `• ${priorityLabel(t.priority)} *${t.title}*${t.due_at ? ' — ' + formatDate(t.due_at) : ''}`
    ).join('\n');
  }
  return '🔍 Pode especificar o que deseja consultar?';
}

// ── Comandos /start /help /resumo ─────────────────────────────────────────────
async function handleCommand(chatId, text) {
  const cmd = text.split(' ')[0].toLowerCase();
  switch (cmd) {
    case '/start':
      await send(chatId,
        `👋 Olá! Sou a *ARIA*, sua assistente pessoal inteligente.\n\n` +
        `Fale comigo naturalmente! Exemplos:\n\n` +
        `📅 _"Aria, agende reunião amanhã às 14h"_\n` +
        `✅ _"Crie uma tarefa: revisar relatório até sexta"_\n` +
        `📝 _"Anote: conceitos de arquitetura hexagonal"_\n` +
        `💊 _"Tomei o omeprazol agora"_\n` +
        `💰 _"Gastei R$50 no almoço"_\n\n` +
        `Use /help para ver todos os comandos.`
      );
      break;
    case '/help':
      await send(chatId,
        `📖 *Comandos ARIA*\n\n` +
        `/resumo — Resumo do dia\n` +
        `/eventos — Próximos eventos\n` +
        `/tarefas — Tarefas pendentes\n` +
        `/notas — Últimas anotações\n` +
        `/financeiro — Resumo financeiro\n` +
        `/saude — Status de saúde\n\n` +
        `Ou simplesmente fale comigo em linguagem natural! 🤖`
      );
      break;
    case '/resumo':
      await bot.sendChatAction(chatId, 'typing');
      const summary = await buildDailySummary();
      await send(chatId, summary);
      break;
    case '/eventos':
      await processIntent(chatId, { intent: 'query', data: { entity: 'events' }, reply: '' }, '');
      break;
    case '/tarefas':
      await processIntent(chatId, { intent: 'query', data: { entity: 'tasks' }, reply: '' }, '');
      break;
    default:
      await send(chatId, '❓ Comando não reconhecido. Use /help para ver os disponíveis.');
  }
}

// ── Envia mensagem formatada (Markdown) ───────────────────────────────────────
async function send(chatId, text) {
  try {
    await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
  } catch {
    // Fallback sem markdown
    await bot.sendMessage(chatId, text.replace(/[*_`]/g, ''));
  }
}

// ── Envia notificação proativa (chamado pelos cron jobs) ───────────────────────
async function sendNotification(text) {
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (!chatId || !bot) return;
  await send(chatId, text);
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function buildDateTime(dateStr, timeStr) {
  if (!dateStr) return new Date();
  const [h, m] = (timeStr || '09:00').split(':');
  const d = new Date(dateStr);
  d.setHours(parseInt(h), parseInt(m), 0, 0);
  return d;
}

function formatDate(d) {
  return new Date(d).toLocaleString('pt-BR', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
}

function priorityLabel(p) {
  return { high: '🔴', medium: '🟡', low: '🟢' }[p] || '⚪';
}

async function buildDailySummary() {
  try {
    const geminiService = require('./geminiService');
    const events = await eventService.listToday();
    const tasks = await taskService.listPending(5);
    return await geminiService.generateDailySummary({ events, tasks, weather: null, bills: [] });
  } catch {
    return '☀️ Bom dia! Confira sua agenda e tarefas de hoje.';
  }
}

function getBot() { return bot; }

module.exports = { init, sendNotification, getBot, send };
