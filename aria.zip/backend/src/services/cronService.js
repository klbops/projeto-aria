const cron = require('node-cron');
const telegramService = require('./telegramService');
const eventService = require('./eventService');
const taskService = require('./taskService');
const financeService = require('./financeService');
const geminiService = require('./geminiService');

// ── Resumo diário — todo dia às 07:30 ────────────────────────────────────────
cron.schedule('30 7 * * *', async () => {
  try {
    const events = await eventService.listToday();
    const tasks = await taskService.listPending(5);
    const bills = await financeService.getUpcomingBills();

    let weather = null;
    try {
      const weatherService = require('./weatherService');
      weather = await weatherService.getCurrent();
    } catch {}

    const summary = await geminiService.generateDailySummary({ events, tasks, weather, bills });
    await telegramService.sendNotification(summary);
  } catch (err) {
    console.error('❌ Cron resumo diário:', err.message);
  }
}, { timezone: 'America/Sao_Paulo' });

// ── Lembretes de eventos — a cada 5 minutos ───────────────────────────────────
cron.schedule('*/5 * * * *', async () => {
  try {
    const upcoming = await eventService.getDue(35);
    for (const event of upcoming) {
      const minutesLeft = Math.round((new Date(event.start_at) - new Date()) / 60000);
      await telegramService.sendNotification(
        `🔔 *Lembrete:* ${event.title}\n` +
        `⏰ Em ${minutesLeft} minutos (${formatTime(event.start_at)})\n` +
        `${event.location ? '📍 ' + event.location : ''}`
      );
    }
  } catch (err) {
    console.error('❌ Cron lembretes:', err.message);
  }
});

// ── Lembrete de água — a cada 2h entre 8h e 20h ──────────────────────────────
cron.schedule('0 8,10,12,14,16,18,20 * * *', async () => {
  try {
    await telegramService.sendNotification(
      `💧 *Hora de beber água!*\nManter-se hidratado melhora o foco e a energia. 🌊`
    );
  } catch {}
}, { timezone: 'America/Sao_Paulo' });

// ── Alerta de contas a vencer — todo dia às 09:00 ────────────────────────────
cron.schedule('0 9 * * *', async () => {
  try {
    const bills = await financeService.getUpcomingBills();
    if (!bills.length) return;
    const list = bills.map(b =>
      `• *${b.title}* — R$ ${parseFloat(b.amount).toFixed(2)} (vence ${formatDate(b.due_at)})`
    ).join('\n');
    await telegramService.sendNotification(
      `💰 *Contas a pagar esta semana:*\n\n${list}\n\n_Acesse o painel para pagar._`
    );
  } catch (err) {
    console.error('❌ Cron contas:', err.message);
  }
}, { timezone: 'America/Sao_Paulo' });

// ── Relatório semanal — todo domingo às 20:00 ─────────────────────────────────
cron.schedule('0 20 * * 0', async () => {
  try {
    const { summary } = await financeService.listAll();
    const tasks = await taskService.listAll({ status: 'done' });
    await telegramService.sendNotification(
      `📊 *Resumo Semanal ARIA*\n\n` +
      `✅ Tarefas concluídas: ${tasks.total}\n` +
      `💰 Receitas: R$ ${parseFloat(summary?.income || 0).toFixed(2)}\n` +
      `💸 Despesas: R$ ${parseFloat(summary?.expense || 0).toFixed(2)}\n\n` +
      `Ótimo trabalho! Tenha uma boa semana. 🚀`
    );
  } catch {}
}, { timezone: 'America/Sao_Paulo' });

function formatTime(d) {
  return new Date(d).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}
function formatDate(d) {
  return new Date(d).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
}

console.log('⏰ Cron jobs registrados:',
  ['resumo diário 07:30', 'lembretes eventos', 'água 2h', 'contas 09:00', 'semanal domingo'].join(' | ')
);
