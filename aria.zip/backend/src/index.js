require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

const app = express();

// ── Middlewares ───────────────────────────────────────────
app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_URL || '*', credentials: true }));
app.use(express.json({ limit: '2mb' }));
app.use(morgan('dev'));
app.use(rateLimit({ windowMs: 60_000, max: 120, message: 'Too many requests' }));

// ── Routes ────────────────────────────────────────────────
app.use('/api/chat',         require('./routes/chat'));
app.use('/api/events',       require('./routes/events'));
app.use('/api/tasks',        require('./routes/tasks'));
app.use('/api/notes',        require('./routes/notes'));
app.use('/api/health',       require('./routes/health'));
app.use('/api/finance',      require('./routes/finance'));
app.use('/api/contacts',     require('./routes/contacts'));
app.use('/api/weather',      require('./routes/weather'));
app.use('/api/auth',         require('./routes/auth'));
app.use('/webhook/telegram', require('./routes/telegramWebhook'));

// ── Health check ─────────────────────────────────────────
app.get('/ping', (_, res) => res.json({ status: 'ok', ts: new Date() }));

// ── Error handler ─────────────────────────────────────────
app.use((err, _req, res, _next) => {
  console.error('❌ Unhandled error:', err);
  res.status(err.status || 500).json({ error: err.message || 'Internal server error' });
});

// ── Boot ──────────────────────────────────────────────────
const PORT = process.env.PORT || 3001;
app.listen(PORT, async () => {
  console.log(`\n🚀 ARIA Backend rodando na porta ${PORT}`);

  // Inicia o bot do Telegram
  try {
    const telegramService = require('./services/telegramService');
    await telegramService.init();
    console.log('🤖 Telegram Bot iniciado');
  } catch (e) {
    console.warn('⚠️  Telegram Bot não iniciado:', e.message);
  }

  // Inicia os cron jobs
  try {
    require('./services/cronService');
    console.log('⏰ Cron jobs iniciados');
  } catch (e) {
    console.warn('⚠️  Cron jobs não iniciados:', e.message);
  }
});

module.exports = app;
