const { createClient } = require('redis');

let client = null;

async function getRedis() {
  if (client && client.isOpen) return client;
  client = createClient({ url: process.env.REDIS_URL });
  client.on('error', (err) => console.error('❌ Redis error:', err.message));
  await client.connect();
  console.log('✅ Redis conectado');
  return client;
}

module.exports = { getRedis };
