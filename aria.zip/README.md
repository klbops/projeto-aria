# ARIA — Assistente Virtual Inteligente

> Chatbot pessoal com Telegram + Gemini AI + n8n + React

---

## Stack

| Camada | Tecnologia |
|--------|-----------|
| Frontend | React 18 + Vite |
| Backend | Node.js + Express |
| IA | Google Gemini 2.0 Flash |
| Bot | Telegram (node-telegram-bot-api) |
| Automação | n8n |
| Banco | PostgreSQL 16 |
| Cache | Redis 7 |
| Deploy | Docker Compose |

---

## Estrutura do Projeto

```
aria/
├── backend/
│   ├── config/          # DB e Redis
│   └── src/
│       ├── routes/      # APIs REST
│       └── services/
│           ├── geminiService.js    ← IA + NLP
│           ├── telegramService.js  ← Bot Telegram
│           ├── cronService.js      ← Jobs agendados
│           ├── eventService.js
│           ├── taskService.js
│           ├── noteService.js
│           ├── healthService.js
│           ├── financeService.js
│           └── weatherService.js
├── frontend/
│   └── src/
│       ├── pages/       # Dashboard, Chat, Eventos, Tarefas, Notas...
│       ├── components/  # Sidebar
│       └── services/    # api.js
├── n8n/workflows/       # Workflows exportados
├── scripts/
│   ├── init.sql         # Schema do banco
│   └── setup.sh
└── docker-compose.yml
```

---

## Configuração Rápida

### 1. Clone e configure

```bash
git clone <repo>
cd aria
chmod +x scripts/setup.sh
./scripts/setup.sh
```

### 2. Edite o `.env`

```env
TELEGRAM_BOT_TOKEN=   # BotFather → /newbot
TELEGRAM_CHAT_ID=     # @userinfobot para descobrir
GEMINI_API_KEY=       # aistudio.google.com
OPENWEATHER_API_KEY=  # openweathermap.org (free)
```

### 3. Suba com Docker

```bash
docker compose up -d
```

### 4. Acesse

| Serviço | URL |
|---------|-----|
| Frontend | http://localhost:3000 |
| Backend API | http://localhost:3001 |
| n8n | http://localhost:5678 |

---

## Como criar o Bot Telegram

1. Abra o Telegram e procure `@BotFather`
2. Envie `/newbot`
3. Escolha um nome: ex `ARIA Pessoal`
4. Escolha um username: ex `aria_meu_bot`
5. Copie o token e coloque em `TELEGRAM_BOT_TOKEN`
6. Envie uma mensagem para o bot
7. Acesse `https://api.telegram.org/bot<TOKEN>/getUpdates`
8. Copie o `chat.id` e coloque em `TELEGRAM_CHAT_ID`

---

## Como usar a IA (exemplos reais)

```
Aria, agende para o dia 10 de março a noite as 18:00 prova de arquitetura de software
→ Cria evento no banco + confirma via Telegram

Aria, faça a seguinte anotação da aula de notação hexadecimal
→ Abre contexto e aguarda o conteúdo

Me lembra de pagar a conta de luz na sexta às 10h
→ Cria tarefa com prazo

Gastei R$50 no almoço hoje
→ Registra despesa

Tomei o omeprazol agora
→ Registra no log de saúde

Quais são meus próximos eventos?
→ Lista eventos do banco
```

---

## n8n — Configurar Workflows

1. Acesse http://localhost:5678
2. Login: admin / admin123
3. Importe os workflows de `n8n/workflows/`
4. Configure as credenciais do Telegram em cada workflow
5. Ative os workflows

### Workflows disponíveis

| Workflow | Função |
|----------|--------|
| `telegram-to-task.json` | Mensagem do Telegram → ARIA API → resposta |
| `daily-summary.json` | Todo dia 07:30 → resumo inteligente → Telegram |

---

## APIs disponíveis

```
POST /api/chat              → Enviar mensagem para a ARIA
GET  /api/chat/history      → Histórico de mensagens

GET  /api/events            → Listar eventos
POST /api/events            → Criar evento
GET  /api/events/today      → Eventos de hoje

GET  /api/tasks             → Listar tarefas
POST /api/tasks             → Criar tarefa
PATCH /api/tasks/:id/done   → Concluir tarefa

GET  /api/notes             → Listar notas
POST /api/notes             → Criar nota
GET  /api/notes/search?q=   → Busca semântica

GET  /api/finance           → Transações + resumo
POST /api/finance           → Registrar transação

GET  /api/health/today      → Resumo de saúde hoje
POST /api/health/log        → Registrar hábito

GET  /api/weather/current   → Clima atual
```

---

## Dev local (sem Docker)

```bash
# Terminal 1 — Backend
cd backend
npm install
npm run dev

# Terminal 2 — Frontend
cd frontend
npm install
npm run dev

# Banco local (precisa de PostgreSQL e Redis rodando)
# Rode o init.sql no seu banco local
```

---

## Cron Jobs automáticos

| Horário | Ação |
|---------|------|
| 07:30 diário | Resumo do dia via Telegram |
| A cada 5 min | Verificação de lembretes de eventos |
| A cada 2h (8-20h) | Lembrete de beber água |
| 09:00 diário | Alerta de contas a vencer |
| Domingo 20h | Relatório semanal |
