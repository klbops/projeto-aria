import { useState, useEffect, useRef, useCallback } from 'react'
import { chatAPI } from '../services/api'
import toast from 'react-hot-toast'
import dayjs from 'dayjs'
import 'dayjs/locale/pt-br'
dayjs.locale('pt-br')

const QUICK_ACTIONS = [
  { label: '📅 Próximos eventos',   msg: 'Quais são meus próximos eventos?' },
  { label: '✅ Tarefas pendentes',  msg: 'Mostre minhas tarefas pendentes' },
  { label: '☀️ Resumo do dia',      msg: 'Me dê um resumo do meu dia' },
  { label: '💊 Lembrete remédio',   msg: 'Me lembra de tomar omeprazol todo dia às 08:00' },
  { label: '💰 Registrar gasto',    msg: 'Gastei R$50 no almoço hoje' },
  { label: '📝 Nova anotação',      msg: 'Quero fazer uma anotação' },
]

export default function ChatPage() {
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [apiKey, setApiKey] = useState(() => localStorage.getItem('gemini_key') || '')
  const [showKeyPrompt, setShowKeyPrompt] = useState(false)
  const bottomRef = useRef(null)
  const inputRef = useRef(null)
  const sessionId = useRef(`web_${Date.now()}`)

  // Carrega histórico
  useEffect(() => {
    chatAPI.history(40).then(r => {
      if (r.data?.length) {
        setMessages(r.data.map(m => ({
          id: m.id,
          role: m.role,
          content: m.content,
          time: m.created_at,
          intent: m.metadata?.intent,
        })))
      } else {
        setMessages([{
          id: 'welcome',
          role: 'assistant',
          content: '👋 Olá! Sou a **ARIA**, sua assistente pessoal inteligente.\n\nFale comigo naturalmente! Exemplos:\n\n📅 _"Aria, agende prova de arquitetura dia 10 às 18h"_\n✅ _"Me lembra de pagar a conta de luz na sexta"_\n📝 _"Faça a seguinte anotação: conceitos de hexadecimal..."_\n💊 _"Tomei o remédio agora"_\n💰 _"Gastei R$50 no almoço"_',
          time: new Date().toISOString(),
        }])
      }
    }).catch(() => {
      setMessages([{
        id: 'welcome',
        role: 'assistant',
        content: '👋 Olá! Sou a **ARIA**. Configure a API Key do Gemini nas configurações para usar o chat com IA real.',
        time: new Date().toISOString(),
      }])
    })
  }, [])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, loading])

  const sendMessage = useCallback(async (text) => {
    const msg = (text || input).trim()
    if (!msg || loading) return

    setInput('')
    setLoading(true)

    // Adiciona mensagem do usuário imediatamente
    const userMsg = { id: Date.now(), role: 'user', content: msg, time: new Date().toISOString() }
    setMessages(prev => [...prev, userMsg])

    try {
      const { data } = await chatAPI.send(msg, sessionId.current)

      const botMsg = {
        id: Date.now() + 1,
        role: 'assistant',
        content: data.reply,
        time: new Date().toISOString(),
        intent: data.intent,
        actionResult: data.actionResult,
      }
      setMessages(prev => [...prev, botMsg])

      // Toast de confirmação para ações
      if (data.intent === 'create_event') toast.success('Evento criado! 📅')
      if (data.intent === 'create_task')  toast.success('Tarefa criada! ✅')
      if (data.intent === 'create_note')  toast.success('Nota salva! 📝')
      if (data.intent === 'finance_log')  toast.success('Transação registrada! 💰')
      if (data.intent === 'health_log')   toast.success('Registrado! 💚')

    } catch (err) {
      const errMsg = err.response?.data?.error || err.message
      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        role: 'assistant',
        content: `❌ Erro ao processar: ${errMsg}\n\nVerifique se o backend está rodando e a API Key do Gemini está configurada no \`.env\`.`,
        time: new Date().toISOString(),
        isError: true,
      }])
    } finally {
      setLoading(false)
      inputRef.current?.focus()
    }
  }, [input, loading])

  const handleKey = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  const clearHistory = async () => {
    await chatAPI.clearHistory()
    setMessages([])
    toast('Histórico limpo')
  }

  return (
    <div style={s.page}>
      {/* Header */}
      <div style={s.header}>
        <div style={s.headerLeft}>
          <div style={s.headerAvatar}>A</div>
          <div>
            <div style={s.headerName}>ARIA</div>
            <div style={s.headerSub}>
              <span style={s.onlineDot} />
              Online · Gemini 2.0 Flash · n8n
            </div>
          </div>
        </div>
        <div style={s.headerActions}>
          <button style={s.iconBtn} onClick={clearHistory} title="Limpar histórico">🗑️</button>
        </div>
      </div>

      {/* Messages */}
      <div style={s.messages}>
        {messages.map((msg) => (
          <MessageBubble key={msg.id} msg={msg} />
        ))}

        {loading && (
          <div style={{ ...s.msgRow, justifyContent: 'flex-start' }} className="msg-anim">
            <div style={s.avatarBot}>A</div>
            <div style={s.bubbleBot}>
              <div style={s.typing}>
                <span style={{ ...s.dot, animationDelay: '0ms' }} />
                <span style={{ ...s.dot, animationDelay: '150ms' }} />
                <span style={{ ...s.dot, animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Quick actions */}
      <div style={s.quickActions}>
        {QUICK_ACTIONS.map(a => (
          <button key={a.label} style={s.chip} onClick={() => sendMessage(a.msg)}>
            {a.label}
          </button>
        ))}
      </div>

      {/* Input */}
      <div style={s.inputArea}>
        <div style={s.inputRow}>
          <textarea
            ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKey}
            placeholder="Fale com a ARIA... (ex: 'agende prova de arquitetura dia 10 às 18h')"
            style={s.textarea}
            rows={1}
            disabled={loading}
          />
          <button
            style={{ ...s.sendBtn, opacity: loading || !input.trim() ? .4 : 1 }}
            onClick={() => sendMessage()}
            disabled={loading || !input.trim()}
          >
            ➤
          </button>
        </div>
        <div style={s.inputHint}>
          Enter para enviar · Shift+Enter para nova linha · Fale naturalmente em português
        </div>
      </div>
    </div>
  )
}

// ── Bolha de mensagem ─────────────────────────────────────────────────────────
function MessageBubble({ msg }) {
  const isBot = msg.role === 'assistant'
  const time = dayjs(msg.time).format('HH:mm')

  // Renderiza markdown simples
  const renderContent = (text) => {
    if (!text) return ''
    return text
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/`(.*?)`/g, `<code style="font-family:var(--mono);background:rgba(255,255,255,.08);padding:1px 5px;border-radius:3px;font-size:11px">$1</code>`)
      .replace(/_(.*?)_/g, '<em>$1</em>')
      .replace(/\n/g, '<br/>')
  }

  const intentBadge = {
    create_event:  { label: '📅 Evento criado', color: '#4f8ef7' },
    create_task:   { label: '✅ Tarefa criada', color: '#22d3a5' },
    create_note:   { label: '📝 Nota salva', color: '#9b72f7' },
    finance_log:   { label: '💰 Transação', color: '#f5a623' },
    health_log:    { label: '💚 Saúde', color: '#22d3a5' },
  }[msg.intent]

  return (
    <div
      style={{ ...s.msgRow, justifyContent: isBot ? 'flex-start' : 'flex-end' }}
      className="msg-anim"
    >
      {isBot && <div style={s.avatarBot}>A</div>}

      <div style={{ maxWidth: '72%' }}>
        {intentBadge && (
          <div style={{ ...s.intentBadge, color: intentBadge.color, borderColor: intentBadge.color + '33' }}>
            {intentBadge.label}
          </div>
        )}
        <div style={{
          ...(isBot ? s.bubbleBot : s.bubbleUser),
          ...(msg.isError ? s.bubbleError : {}),
        }}>
          <div
            style={s.msgText}
            dangerouslySetInnerHTML={{ __html: renderContent(msg.content) }}
          />
        </div>
        <div style={{ ...s.msgTime, textAlign: isBot ? 'left' : 'right' }}>{time}</div>
      </div>

      {!isBot && <div style={s.avatarUser}>U</div>}
    </div>
  )
}

// ── Styles ────────────────────────────────────────────────────────────────────
const s = {
  page: {
    flex: 1, display: 'flex', flexDirection: 'column',
    height: '100vh', overflow: 'hidden', background: 'var(--bg0)',
  },
  header: {
    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    padding: '14px 20px', background: 'var(--bg1)',
    borderBottom: '1px solid var(--border)',
  },
  headerLeft: { display: 'flex', alignItems: 'center', gap: '10px' },
  headerAvatar: {
    width: '34px', height: '34px', borderRadius: '50%',
    background: 'linear-gradient(135deg, #4f8ef7, #9b72f7)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontWeight: 800, fontSize: '14px',
    boxShadow: '0 0 15px rgba(79,142,247,.3)',
  },
  headerName: { fontWeight: 700, fontSize: '14px' },
  headerSub: {
    fontSize: '11px', color: 'var(--t3)',
    display: 'flex', alignItems: 'center', gap: '5px', marginTop: '1px',
  },
  onlineDot: {
    width: '6px', height: '6px', borderRadius: '50%',
    background: 'var(--green)', display: 'inline-block',
    boxShadow: '0 0 6px var(--green)',
  },
  headerActions: { display: 'flex', gap: '6px' },
  iconBtn: {
    background: 'transparent', border: 'none', cursor: 'pointer',
    fontSize: '16px', padding: '6px', borderRadius: '6px',
    color: 'var(--t3)', transition: 'color .15s',
  },
  messages: {
    flex: 1, overflow: 'auto', padding: '20px',
    display: 'flex', flexDirection: 'column', gap: '12px',
  },
  msgRow: { display: 'flex', gap: '8px', alignItems: 'flex-end' },
  avatarBot: {
    width: '26px', height: '26px', borderRadius: '8px', flexShrink: 0,
    background: 'linear-gradient(135deg, #4f8ef7, #9b72f7)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontWeight: 800, fontSize: '11px', marginBottom: '16px',
  },
  avatarUser: {
    width: '26px', height: '26px', borderRadius: '8px', flexShrink: 0,
    background: 'var(--surface2)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontWeight: 700, fontSize: '11px', color: 'var(--t2)', marginBottom: '16px',
  },
  bubbleBot: {
    background: 'var(--surface)', border: '1px solid var(--border2)',
    borderRadius: '12px 12px 12px 3px',
    padding: '10px 14px',
  },
  bubbleUser: {
    background: 'linear-gradient(135deg, #2a4fa8, #4f8ef7)',
    borderRadius: '12px 12px 3px 12px',
    padding: '10px 14px',
  },
  bubbleError: {
    background: 'rgba(240,86,118,.1)', border: '1px solid rgba(240,86,118,.25)',
  },
  msgText: { fontSize: '13px', lineHeight: 1.55, color: 'var(--t1)' },
  msgTime: { fontSize: '10px', color: 'var(--t3)', marginTop: '4px', paddingLeft: '2px' },
  intentBadge: {
    fontSize: '10px', fontWeight: 700, marginBottom: '4px',
    paddingLeft: '2px', border: '1px solid', borderRadius: '5px',
    display: 'inline-block', padding: '2px 7px', background: 'rgba(0,0,0,.2)',
  },
  typing: { display: 'flex', gap: '4px', alignItems: 'center', padding: '2px 0' },
  dot: {
    width: '6px', height: '6px', borderRadius: '50%',
    background: 'var(--t3)', display: 'inline-block',
    animation: 'typing 0.8s infinite',
  },
  quickActions: {
    padding: '8px 16px', display: 'flex', gap: '6px',
    overflowX: 'auto', borderTop: '1px solid var(--border)',
    background: 'var(--bg1)',
  },
  chip: {
    padding: '6px 12px', background: 'var(--surface)',
    border: '1px solid var(--border2)', borderRadius: '20px',
    fontSize: '11px', color: 'var(--t2)', cursor: 'pointer',
    whiteSpace: 'nowrap', fontFamily: 'var(--font)',
    transition: 'all .15s',
  },
  inputArea: {
    padding: '12px 16px 14px', background: 'var(--bg1)',
    borderTop: '1px solid var(--border)',
  },
  inputRow: { display: 'flex', gap: '10px', alignItems: 'flex-end' },
  textarea: {
    flex: 1, background: 'var(--surface)', border: '1px solid var(--border2)',
    borderRadius: '12px', padding: '11px 14px',
    fontFamily: 'var(--font)', fontSize: '13px', color: 'var(--t1)',
    resize: 'none', outline: 'none', maxHeight: '120px', minHeight: '44px',
    lineHeight: 1.5, transition: 'border-color .15s',
  },
  sendBtn: {
    width: '44px', height: '44px', borderRadius: '12px',
    background: 'linear-gradient(135deg, #4f8ef7, #2a4fa8)',
    border: 'none', color: '#fff', fontSize: '16px',
    cursor: 'pointer', display: 'flex', alignItems: 'center',
    justifyContent: 'center', flexShrink: 0,
    boxShadow: '0 4px 15px rgba(79,142,247,.25)',
    transition: 'all .15s',
  },
  inputHint: {
    fontSize: '10px', color: 'var(--t3)', marginTop: '6px', textAlign: 'center',
    fontFamily: 'var(--mono)',
  },
}
