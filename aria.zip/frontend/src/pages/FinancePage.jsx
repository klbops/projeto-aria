import { useState, useEffect } from 'react'
import { financeAPI } from '../services/api'
import toast from 'react-hot-toast'
import dayjs from 'dayjs'

export default function FinancePage() {
  const [data, setData] = useState({ items:[], summary:{} })
  const [form, setForm] = useState({ title:'', amount:'', type:'expense', category:'Geral', due_at:'' })

  const load = () => financeAPI.list({ limit:50 }).then(r=>setData(r.data)).catch(()=>{})
  useEffect(() => { load() }, [])

  const submit = async () => {
    if (!form.title || !form.amount) return toast.error('Título e valor obrigatórios')
    await financeAPI.create({ ...form, amount: parseFloat(form.amount) })
    toast.success(form.type === 'income' ? 'Receita registrada! 💚' : 'Despesa registrada! 💸')
    setForm({ title:'', amount:'', type:'expense', category:'Geral', due_at:'' })
    load()
  }

  const pay = async (id) => { await financeAPI.pay(id); toast.success('Marcado como pago!'); load() }
  const del = async (id) => { await financeAPI.delete(id); load() }

  const income = parseFloat(data.summary?.income || 0)
  const expense = parseFloat(data.summary?.expense || 0)
  const balance = income - expense

  return (
    <div style={s.page} className="fade-up">
      <div style={s.header}><div style={s.title}>💰 Financeiro</div></div>
      <div style={s.summary}>
        {[
          { label:'Receitas', val:income, color:'#22d3a5' },
          { label:'Despesas', val:expense, color:'#f05676' },
          { label:'Saldo', val:balance, color: balance>=0 ? '#22d3a5' : '#f05676' },
        ].map((c,i)=>(
          <div key={i} style={s.sumCard}>
            <div style={s.sumLabel}>{c.label}</div>
            <div style={{ ...s.sumVal, color:c.color }}>R$ {c.val.toFixed(2)}</div>
          </div>
        ))}
      </div>
      <div style={s.layout}>
        <div style={s.form}>
          <div style={s.formTitle}>+ Registrar</div>
          {[
            {label:'Descrição *',key:'title',type:'text',ph:'Ex: Almoço, Salário...'},
            {label:'Valor *',key:'amount',type:'number',ph:'0.00'},
            {label:'Categoria',key:'category',type:'text',ph:'Alimentação, Moradia...'},
            {label:'Vencimento',key:'due_at',type:'date'},
          ].map(f=>(
            <div key={f.key} style={s.field}>
              <label style={s.label}>{f.label}</label>
              <input type={f.type} placeholder={f.ph} value={form[f.key]} onChange={e=>setForm(p=>({...p,[f.key]:e.target.value}))} style={s.input} />
            </div>
          ))}
          <div style={s.field}>
            <label style={s.label}>Tipo</label>
            <select value={form.type} onChange={e=>setForm(p=>({...p,type:e.target.value}))} style={s.input}>
              <option value="expense">💸 Despesa</option>
              <option value="income">💚 Receita</option>
            </select>
          </div>
          <button style={s.btn} onClick={submit}>Registrar</button>
          <div style={s.hint}>💬 Ou diga: "gastei R$50 no almoço"</div>
        </div>
        <div style={s.list}>
          {(data.items||[]).length===0 && <div style={s.empty}>Nenhuma transação registrada.</div>}
          {(data.items||[]).map(t=>(
            <div key={t.id} style={{ ...s.card, borderLeft:`3px solid ${t.type==='income'?'#22d3a5':'#f05676'}` }}>
              <div style={{ flex:1 }}>
                <div style={{ display:'flex', gap:'8px', alignItems:'center' }}>
                  <span style={{ fontWeight:700, fontSize:'13px' }}>{t.title}</span>
                  <span style={{ fontSize:'9px', background:'var(--bg3)', padding:'1px 6px', borderRadius:'4px', color:'var(--t3)', fontWeight:700 }}>{t.category}</span>
                  {!t.paid && t.type==='expense' && <span style={{ fontSize:'9px', background:'rgba(245,166,35,.15)', color:'#f5a623', padding:'1px 6px', borderRadius:'4px', fontWeight:700 }}>Pendente</span>}
                </div>
                <div style={{ fontSize:'10px', color:'var(--t3)', marginTop:'3px', fontFamily:'var(--mono)' }}>
                  {dayjs(t.created_at).format('DD/MM/YYYY')}
                  {t.due_at && ` · Vence: ${dayjs(t.due_at).format('DD/MM')}`}
                </div>
              </div>
              <div style={{ display:'flex', alignItems:'center', gap:'8px' }}>
                <span style={{ fontFamily:'var(--mono)', fontWeight:700, color: t.type==='income'?'#22d3a5':'#f05676', fontSize:'14px' }}>
                  {t.type==='income'?'+':'-'} R$ {parseFloat(t.amount).toFixed(2)}
                </span>
                {!t.paid && t.type==='expense' && <button style={s.payBtn} onClick={()=>pay(t.id)}>Pagar</button>}
                <button style={s.delBtn} onClick={()=>del(t.id)}>🗑️</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

const s = {
  page:{flex:1,overflow:'auto',padding:'20px'},
  header:{display:'flex',alignItems:'center',marginBottom:'16px'},
  title:{fontFamily:'var(--mono)',fontWeight:800,fontSize:'18px'},
  summary:{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:'10px',marginBottom:'16px'},
  sumCard:{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:'10px',padding:'14px'},
  sumLabel:{fontSize:'10px',fontWeight:700,color:'var(--t3)',textTransform:'uppercase',letterSpacing:'.8px',marginBottom:'6px'},
  sumVal:{fontFamily:'var(--mono)',fontWeight:800,fontSize:'22px'},
  layout:{display:'grid',gridTemplateColumns:'280px 1fr',gap:'16px'},
  form:{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:'12px',padding:'16px',height:'fit-content'},
  formTitle:{fontWeight:700,marginBottom:'12px',fontSize:'13px'},
  field:{marginBottom:'10px'},
  label:{display:'block',fontSize:'10px',fontWeight:700,color:'var(--t3)',textTransform:'uppercase',letterSpacing:'.8px',marginBottom:'4px'},
  input:{width:'100%',background:'var(--bg3)',border:'1px solid var(--border2)',borderRadius:'7px',padding:'8px 10px',color:'var(--t1)',fontFamily:'var(--font)',fontSize:'12px',outline:'none'},
  btn:{width:'100%',background:'linear-gradient(135deg,#4f8ef7,#2a4fa8)',border:'none',borderRadius:'8px',color:'#fff',padding:'10px',fontWeight:700,cursor:'pointer',fontFamily:'var(--font)',fontSize:'13px',marginTop:'4px'},
  hint:{fontSize:'10px',color:'var(--t3)',marginTop:'8px',textAlign:'center',fontStyle:'italic'},
  list:{display:'flex',flexDirection:'column',gap:'8px'},
  card:{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:'10px',padding:'12px 16px',display:'flex',alignItems:'center',justifyContent:'space-between',gap:'12px'},
  payBtn:{background:'rgba(34,211,165,.15)',border:'1px solid rgba(34,211,165,.3)',borderRadius:'6px',color:'#22d3a5',padding:'4px 10px',cursor:'pointer',fontSize:'11px',fontWeight:700,fontFamily:'var(--font)'},
  delBtn:{background:'transparent',border:'none',cursor:'pointer',fontSize:'13px',opacity:.4},
  empty:{color:'var(--t3)',fontSize:'13px',textAlign:'center',padding:'40px'},
}
