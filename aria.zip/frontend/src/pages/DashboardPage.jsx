// DashboardPage.jsx
import { useState, useEffect } from 'react'
import { eventsAPI, tasksAPI, weatherAPI, financeAPI } from '../services/api'
import dayjs from 'dayjs'
import 'dayjs/locale/pt-br'
dayjs.locale('pt-br')

export default function DashboardPage({ onNavigate }) {
  const [events, setEvents] = useState([])
  const [tasks, setTasks] = useState([])
  const [weather, setWeather] = useState(null)
  const [bills, setBills] = useState([])

  useEffect(() => {
    eventsAPI.today().then(r => setEvents(r.data)).catch(() => {})
    tasksAPI.pending(5).then(r => setTasks(r.data)).catch(() => {})
    weatherAPI.current().then(r => setWeather(r.data)).catch(() => {})
    financeAPI.bills().then(r => setBills(r.data)).catch(() => {})
  }, [])

  return (
    <div style={{ flex: 1, overflow: 'auto', padding: '20px' }} className="fade-up">
      <div style={d.title}>Dashboard <span style={d.sub}>{dayjs().format('dddd, D [de] MMMM')}</span></div>

      {/* Stats */}
      <div style={d.statsRow}>
        {[
          { label: 'Eventos hoje', val: events.length, icon: '📅', color: '#4f8ef7', onClick: () => onNavigate('events') },
          { label: 'Tarefas pendentes', val: tasks.length, icon: '✅', color: '#9b72f7', onClick: () => onNavigate('tasks') },
          { label: 'Contas a pagar', val: bills.length, icon: '💰', color: '#f5a623', onClick: () => onNavigate('finance') },
          { label: 'Clima', val: weather ? `${weather.temp}°C` : '—', icon: '🌤️', color: '#22d3a5', sub: weather?.description },
        ].map((s, i) => (
          <div key={i} style={{ ...d.statCard, '--c': s.color }} onClick={s.onClick}>
            <div style={{ fontSize: '22px', marginBottom: '8px' }}>{s.icon}</div>
            <div style={{ ...d.statVal, color: s.color }}>{s.val}</div>
            <div style={d.statLabel}>{s.label}</div>
            {s.sub && <div style={d.statSub}>{s.sub}</div>}
          </div>
        ))}
      </div>

      <div style={d.grid}>
        {/* Agenda do dia */}
        <div style={d.card}>
          <div style={d.cardHeader}>
            <span style={d.cardTitle}>📅 Agenda de Hoje</span>
            <button style={d.linkBtn} onClick={() => onNavigate('events')}>Ver tudo →</button>
          </div>
          {events.length === 0
            ? <div style={d.empty}>Nenhum evento hoje.</div>
            : events.map(e => (
              <div key={e.id} style={d.eventRow}>
                <div style={d.eventTime}>{dayjs(e.start_at).format('HH:mm')}</div>
                <div style={d.eventDot} />
                <div>
                  <div style={d.eventTitle}>{e.title}</div>
                  {e.location && <div style={d.eventSub}>📍 {e.location}</div>}
                </div>
              </div>
            ))
          }
        </div>

        {/* Tarefas pendentes */}
        <div style={d.card}>
          <div style={d.cardHeader}>
            <span style={d.cardTitle}>✅ Tarefas Pendentes</span>
            <button style={d.linkBtn} onClick={() => onNavigate('tasks')}>Ver tudo →</button>
          </div>
          {tasks.length === 0
            ? <div style={d.empty}>Nenhuma tarefa pendente!</div>
            : tasks.map(t => (
              <div key={t.id} style={d.taskRow}>
                <div style={{ ...d.pDot, background: { high: '#f05676', medium: '#f5a623', low: '#22d3a5' }[t.priority] || '#4e6580' }} />
                <div style={d.taskTitle}>{t.title}</div>
                {t.due_at && <div style={d.taskDue}>{dayjs(t.due_at).format('DD/MM')}</div>}
              </div>
            ))
          }
        </div>

        {/* Contas a pagar */}
        <div style={d.card}>
          <div style={d.cardHeader}>
            <span style={d.cardTitle}>💰 Contas da Semana</span>
            <button style={d.linkBtn} onClick={() => onNavigate('finance')}>Ver tudo →</button>
          </div>
          {bills.length === 0
            ? <div style={d.empty}>Nenhuma conta a pagar esta semana!</div>
            : bills.map(b => (
              <div key={b.id} style={d.billRow}>
                <div style={d.billTitle}>{b.title}</div>
                <div style={d.billAmt}>R$ {parseFloat(b.amount).toFixed(2)}</div>
              </div>
            ))
          }
        </div>
      </div>

      {/* Quick message */}
      <div style={d.aiCard}>
        <div style={d.aiIcon}>✦</div>
        <div>
          <div style={d.aiTitle}>Fale com a ARIA</div>
          <div style={d.aiSub}>Use linguagem natural para agendar, criar tarefas, anotar e muito mais.</div>
        </div>
        <button style={d.aiBtn} onClick={() => onNavigate('chat')}>Abrir Chat →</button>
      </div>
    </div>
  )
}

const d = {
  title: { fontFamily: 'var(--mono)', fontWeight: 800, fontSize: '20px', marginBottom: '18px' },
  sub: { fontWeight: 400, color: 'var(--t3)', fontSize: '13px', marginLeft: '10px' },
  statsRow: { display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '10px', marginBottom: '16px' },
  statCard: {
    background: 'var(--surface)', border: '1px solid var(--border)',
    borderRadius: '12px', padding: '16px', cursor: 'pointer',
    transition: 'all .2s', position: 'relative', overflow: 'hidden',
  },
  statVal: { fontSize: '26px', fontWeight: 800, fontFamily: 'var(--mono)', lineHeight: 1 },
  statLabel: { fontSize: '11px', color: 'var(--t3)', marginTop: '4px', fontWeight: 600 },
  statSub: { fontSize: '10px', color: 'var(--t3)', marginTop: '2px', textTransform: 'capitalize' },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '12px', marginBottom: '14px' },
  card: {
    background: 'var(--surface)', border: '1px solid var(--border)',
    borderRadius: '12px', padding: '16px',
  },
  cardHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' },
  cardTitle: { fontWeight: 700, fontSize: '13px' },
  linkBtn: { background: 'none', border: 'none', color: 'var(--accent)', fontSize: '11px', cursor: 'pointer', fontFamily: 'var(--font)' },
  empty: { fontSize: '12px', color: 'var(--t3)', padding: '8px 0' },
  eventRow: { display: 'flex', alignItems: 'flex-start', gap: '8px', padding: '6px 0', borderBottom: '1px solid var(--border)' },
  eventTime: { fontFamily: 'var(--mono)', fontSize: '10px', color: 'var(--t3)', minWidth: '36px', paddingTop: '2px' },
  eventDot: { width: '7px', height: '7px', borderRadius: '50%', background: 'var(--accent)', marginTop: '4px', flexShrink: 0 },
  eventTitle: { fontSize: '12px', fontWeight: 600 },
  eventSub: { fontSize: '10px', color: 'var(--t3)' },
  taskRow: { display: 'flex', alignItems: 'center', gap: '8px', padding: '7px 0', borderBottom: '1px solid var(--border)' },
  pDot: { width: '7px', height: '7px', borderRadius: '50%', flexShrink: 0 },
  taskTitle: { flex: 1, fontSize: '12px', fontWeight: 500 },
  taskDue: { fontSize: '10px', fontFamily: 'var(--mono)', color: 'var(--t3)' },
  billRow: { display: 'flex', justifyContent: 'space-between', padding: '7px 0', borderBottom: '1px solid var(--border)' },
  billTitle: { fontSize: '12px' },
  billAmt: { fontSize: '12px', fontFamily: 'var(--mono)', color: '#f05676', fontWeight: 700 },
  aiCard: {
    background: 'linear-gradient(135deg, rgba(79,142,247,.12), rgba(155,114,247,.08))',
    border: '1px solid rgba(79,142,247,.25)', borderRadius: '12px',
    padding: '16px 20px', display: 'flex', alignItems: 'center', gap: '14px',
  },
  aiIcon: { fontSize: '24px', color: '#4f8ef7' },
  aiTitle: { fontWeight: 700, fontSize: '14px', marginBottom: '2px' },
  aiSub: { fontSize: '12px', color: 'var(--t2)' },
  aiBtn: {
    marginLeft: 'auto', background: 'linear-gradient(135deg, #4f8ef7, #2a4fa8)',
    border: 'none', borderRadius: '8px', color: '#fff', padding: '8px 16px',
    fontSize: '12px', fontWeight: 700, cursor: 'pointer', whiteSpace: 'nowrap',
    fontFamily: 'var(--font)',
  },
}
