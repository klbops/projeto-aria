import { useState, useEffect } from 'react'
import { eventsAPI } from '../services/api'
import toast from 'react-hot-toast'
import dayjs from 'dayjs'

export default function EventsPage() {
  const [events, setEvents] = useState([])
  const [form, setForm] = useState({ title: '', start_at: '', end_at: '', location: '', description: '', reminder_min: 30 })
  const [loading, setLoading] = useState(false)

  const load = () => eventsAPI.list({ limit: 50 }).then(r => setEvents(r.data.items || r.data)).catch(() => {})
  useEffect(() => { load() }, [])

  const submit = async () => {
    if (!form.title || !form.start_at) return toast.error('Título e data são obrigatórios')
    setLoading(true)
    try {
      await eventsAPI.create({ ...form, start_at: new Date(form.start_at), end_at: form.end_at ? new Date(form.end_at) : null })
      toast.success('Evento criado! 📅')
      setForm({ title: '', start_at: '', end_at: '', location: '', description: '', reminder_min: 30 })
      load()
    } catch(e) { toast.error(e.response?.data?.error || 'Erro') } finally { setLoading(false) }
  }

  const del = async (id) => {
    await eventsAPI.delete(id)
    toast.success('Evento removido')
    load()
  }

  return (
    <div style={s.page} className="fade-up">
      <div style={s.header}>
        <div style={s.title}>📅 Agenda</div>
      </div>
      <div style={s.layout}>
        {/* Form */}
        <div style={s.form}>
          <div style={s.formTitle}>+ Novo Evento</div>
          {[
            { label: 'Título *', key: 'title', type: 'text', ph: 'Nome do evento' },
            { label: 'Início *', key: 'start_at', type: 'datetime-local' },
            { label: 'Fim', key: 'end_at', type: 'datetime-local' },
            { label: 'Local', key: 'location', type: 'text', ph: 'Onde?' },
            { label: 'Descrição', key: 'description', type: 'text', ph: 'Detalhes...' },
          ].map(f => (
            <div key={f.key} style={s.field}>
              <label style={s.label}>{f.label}</label>
              <input
                type={f.type} placeholder={f.ph}
                value={form[f.key]}
                onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                style={s.input}
              />
            </div>
          ))}
          <div style={s.field}>
            <label style={s.label}>Lembrete (min antes)</label>
            <input type="number" value={form.reminder_min} onChange={e => setForm(p => ({...p,reminder_min:e.target.value}))} style={s.input} />
          </div>
          <button style={s.btn} onClick={submit} disabled={loading}>{loading ? 'Salvando...' : 'Criar Evento'}</button>
          <div style={s.hint}>💬 Ou diga à ARIA: "agende prova de arquitetura dia 10 às 18h"</div>
        </div>
        {/* List */}
        <div style={s.list}>
          {events.length === 0 && <div style={s.empty}>Nenhum evento cadastrado. Crie um ou peça à ARIA!</div>}
          {events.map(e => (
            <div key={e.id} style={s.card}>
              <div style={s.cardLeft}>
                <div style={s.cardTime}>{dayjs(e.start_at).format('DD/MM HH:mm')}</div>
                <div style={s.cardTitle}>{e.title}</div>
                {e.location && <div style={s.cardSub}>📍 {e.location}</div>}
                {e.description && <div style={s.cardSub}>{e.description}</div>}
                <div style={s.cardSub}>🔔 {e.reminder_min} min antes</div>
              </div>
              <button style={s.delBtn} onClick={() => del(e.id)}>🗑️</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

const s = {
  page: { flex:1, overflow:'auto', padding:'20px' },
  header: { display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:'16px' },
  title: { fontFamily:'var(--mono)', fontWeight:800, fontSize:'18px' },
  layout: { display:'grid', gridTemplateColumns:'300px 1fr', gap:'16px' },
  form: { background:'var(--surface)', border:'1px solid var(--border)', borderRadius:'12px', padding:'16px' },
  formTitle: { fontWeight:700, marginBottom:'12px', fontSize:'13px' },
  field: { marginBottom:'10px' },
  label: { display:'block', fontSize:'10px', fontWeight:700, color:'var(--t3)', textTransform:'uppercase', letterSpacing:'.8px', marginBottom:'4px' },
  input: { width:'100%', background:'var(--bg3)', border:'1px solid var(--border2)', borderRadius:'7px', padding:'8px 10px', color:'var(--t1)', fontFamily:'var(--font)', fontSize:'12px', outline:'none' },
  btn: { width:'100%', background:'linear-gradient(135deg,#4f8ef7,#2a4fa8)', border:'none', borderRadius:'8px', color:'#fff', padding:'10px', fontWeight:700, cursor:'pointer', fontFamily:'var(--font)', fontSize:'13px', marginTop:'4px' },
  hint: { fontSize:'10px', color:'var(--t3)', marginTop:'8px', textAlign:'center', fontStyle:'italic' },
  list: { display:'flex', flexDirection:'column', gap:'8px' },
  card: { background:'var(--surface)', border:'1px solid var(--border)', borderRadius:'10px', padding:'14px 16px', display:'flex', alignItems:'flex-start', justifyContent:'space-between', borderLeft:'3px solid var(--accent)' },
  cardLeft: { flex:1 },
  cardTime: { fontFamily:'var(--mono)', fontSize:'11px', color:'var(--accent)', marginBottom:'4px', fontWeight:600 },
  cardTitle: { fontWeight:700, fontSize:'14px', marginBottom:'4px' },
  cardSub: { fontSize:'11px', color:'var(--t3)', marginTop:'2px' },
  delBtn: { background:'transparent', border:'none', cursor:'pointer', fontSize:'14px', opacity:.5, padding:'4px' },
  empty: { color:'var(--t3)', fontSize:'13px', textAlign:'center', padding:'40px' },
}
