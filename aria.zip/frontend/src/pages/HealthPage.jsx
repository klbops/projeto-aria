import { useState, useEffect } from 'react'
import { healthAPI } from '../services/api'
import toast from 'react-hot-toast'

export default function HealthPage() {
  const [today, setToday] = useState([])
  const [logs, setLogs] = useState([])

  const load = () => {
    healthAPI.today().then(r=>setToday(r.data)).catch(()=>{})
    healthAPI.logs().then(r=>setLogs(r.data)).catch(()=>{})
  }
  useEffect(() => { load() }, [])

  const logQuick = async (type, value, unit, notes) => {
    await healthAPI.log({ type, value, unit, notes })
    toast.success(`${notes || type} registrado! 💚`)
    load()
  }

  const get = (type) => today.find(t=>t.type===type)

  const waterTotal = parseFloat(get('water')?.total || 0)
  const waterPct = Math.min((waterTotal/2)*100, 100)

  return (
    <div style={s.page} className="fade-up">
      <div style={s.header}><div style={s.title}>💚 Saúde</div></div>

      {/* Hábitos rápidos */}
      <div style={s.habitsGrid}>
        {/* Água */}
        <div style={s.habitCard}>
          <div style={s.habitHeader}><span style={{fontSize:'22px'}}>💧</span><div><div style={s.habitName}>Hidratação</div><div style={s.habitSub}>Meta: 2L</div></div></div>
          <div style={s.progressBg}><div style={{ ...s.progressFill, width:`${waterPct}%`, background:'linear-gradient(90deg,#28d4e8,#4f8ef7)' }} /></div>
          <div style={s.progressText}><span>{waterTotal.toFixed(1)}L consumidos</span><span style={{color:'var(--t3)'}}>{waterPct.toFixed(0)}%</span></div>
          <div style={s.quickBtns}>
            <button style={s.qBtn} onClick={()=>logQuick('water',0.25,'L','💧 +250ml')}>+250ml</button>
            <button style={s.qBtn} onClick={()=>logQuick('water',0.5,'L','💧 +500ml')}>+500ml</button>
            <button style={s.qBtn} onClick={()=>logQuick('water',1,'L','💧 +1L')}>+1L</button>
          </div>
        </div>

        {/* Exercício */}
        <div style={s.habitCard}>
          <div style={s.habitHeader}><span style={{fontSize:'22px'}}>🏃</span><div><div style={s.habitName}>Exercício</div><div style={s.habitSub}>Meta: 60 min</div></div></div>
          <div style={s.progressBg}><div style={{ ...s.progressFill, width:`${Math.min(((parseFloat(get('exercise')?.total||0))/60)*100,100)}%`, background:'linear-gradient(90deg,#22d3a5,#28d4e8)' }} /></div>
          <div style={s.progressText}><span>{get('exercise')?.total||0} min hoje</span></div>
          <div style={s.quickBtns}>
            <button style={s.qBtn} onClick={()=>logQuick('exercise',30,'min','🏃 Caminhada 30min')}>30 min</button>
            <button style={s.qBtn} onClick={()=>logQuick('exercise',60,'min','🏋️ Academia 60min')}>60 min</button>
          </div>
        </div>

        {/* Sono */}
        <div style={s.habitCard}>
          <div style={s.habitHeader}><span style={{fontSize:'22px'}}>😴</span><div><div style={s.habitName}>Sono</div><div style={s.habitSub}>Meta: 8h</div></div></div>
          <div style={s.progressBg}><div style={{ ...s.progressFill, width:`${Math.min(((parseFloat(get('sleep')?.total||0))/8)*100,100)}%`, background:'linear-gradient(90deg,#9b72f7,#4f8ef7)' }} /></div>
          <div style={s.progressText}><span>{get('sleep')?.total||0}h dormidas</span></div>
          <div style={s.quickBtns}>
            {[6,7,8,9].map(h=><button key={h} style={s.qBtn} onClick={()=>logQuick('sleep',h,'h',`😴 ${h}h de sono`)}>{h}h</button>)}
          </div>
        </div>

        {/* Remédios */}
        <div style={s.habitCard}>
          <div style={s.habitHeader}><span style={{fontSize:'22px'}}>💊</span><div><div style={s.habitName}>Medicamentos</div><div style={s.habitSub}>Registrar tomada</div></div></div>
          <div style={s.quickBtns} style={{flexDirection:'column',gap:'6px'}}>
            {['Omeprazol','Vitamina D','Ômega 3'].map(m=>(
              <button key={m} style={{...s.qBtn, width:'100%', textAlign:'left', padding:'8px 12px'}} onClick={()=>logQuick('medication',1,'dose',`💊 Tomou ${m}`)}>
                💊 {m}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Histórico */}
      <div style={s.card}>
        <div style={s.cardTitle}>📋 Histórico Recente</div>
        {logs.length === 0 && <div style={s.empty}>Nenhum registro ainda. Use os botões acima!</div>}
        {logs.slice(0,15).map(l=>(
          <div key={l.id} style={s.logRow}>
            <span style={{fontSize:'16px'}}>{{ water:'💧', exercise:'🏃', sleep:'😴', medication:'💊' }[l.type]||'❤️'}</span>
            <div style={{flex:1}}>
              <span style={{fontSize:'12px',fontWeight:500}}>{l.notes || l.type}</span>
              {l.value && <span style={{fontSize:'11px',color:'var(--t3)',marginLeft:'8px'}}>{l.value}{l.unit}</span>}
            </div>
            <span style={{fontSize:'10px',color:'var(--t3)',fontFamily:'var(--mono)'}}>{new Date(l.logged_at).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

const s = {
  page:{flex:1,overflow:'auto',padding:'20px'},
  header:{display:'flex',alignItems:'center',marginBottom:'16px'},
  title:{fontFamily:'var(--mono)',fontWeight:800,fontSize:'18px'},
  habitsGrid:{display:'grid',gridTemplateColumns:'repeat(2,1fr)',gap:'12px',marginBottom:'16px'},
  habitCard:{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:'12px',padding:'16px'},
  habitHeader:{display:'flex',alignItems:'center',gap:'10px',marginBottom:'12px'},
  habitName:{fontWeight:700,fontSize:'13px'},
  habitSub:{fontSize:'10px',color:'var(--t3)'},
  progressBg:{height:'6px',background:'var(--border)',borderRadius:'3px',overflow:'hidden',marginBottom:'6px'},
  progressFill:{height:'100%',borderRadius:'3px',transition:'width .5s'},
  progressText:{display:'flex',justifyContent:'space-between',fontSize:'10px',color:'var(--t2)',marginBottom:'10px'},
  quickBtns:{display:'flex',gap:'6px',flexWrap:'wrap'},
  qBtn:{background:'var(--surface2)',border:'1px solid var(--border2)',borderRadius:'7px',color:'var(--t1)',padding:'5px 10px',cursor:'pointer',fontSize:'11px',fontWeight:600,fontFamily:'var(--font)'},
  card:{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:'12px',padding:'16px'},
  cardTitle:{fontWeight:700,fontSize:'13px',marginBottom:'12px'},
  logRow:{display:'flex',alignItems:'center',gap:'10px',padding:'7px 0',borderBottom:'1px solid var(--border)'},
  empty:{color:'var(--t3)',fontSize:'12px',padding:'16px 0'},
}
