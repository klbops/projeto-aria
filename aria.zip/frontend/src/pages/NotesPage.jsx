import { useState, useEffect } from 'react'
import { notesAPI } from '../services/api'
import toast from 'react-hot-toast'
import dayjs from 'dayjs'

export default function NotesPage() {
  const [notes, setNotes] = useState([])
  const [form, setForm] = useState({ title:'', content:'', tags:'' })
  const [search, setSearch] = useState('')
  const [searching, setSearching] = useState(false)
  const [editing, setEditing] = useState(null)

  const load = () => notesAPI.list({ limit: 50 }).then(r => setNotes(r.data.items || [])).catch(() => {})
  useEffect(() => { load() }, [])

  const submit = async () => {
    if (!form.content) return toast.error('Conteúdo obrigatório')
    const payload = { ...form, tags: form.tags ? form.tags.split(',').map(t=>t.trim()) : [] }
    if (editing) {
      await notesAPI.update(editing, payload)
      toast.success('Nota atualizada! 📝')
      setEditing(null)
    } else {
      await notesAPI.create(payload)
      toast.success('Nota salva! 📝')
    }
    setForm({ title:'', content:'', tags:'' })
    load()
  }

  const semanticSearch = async () => {
    if (!search.trim()) return load()
    setSearching(true)
    try {
      const r = await notesAPI.search(search)
      setNotes(r.data)
    } catch { toast.error('Erro na busca') }
    finally { setSearching(false) }
  }

  const del = async (id) => { await notesAPI.delete(id); load() }

  const startEdit = (n) => {
    setEditing(n.id)
    setForm({ title: n.title||'', content: n.content, tags: (n.tags||[]).join(', ') })
  }

  return (
    <div style={s.page} className="fade-up">
      <div style={s.header}>
        <div style={s.title}>📝 Notas</div>
        <div style={{ display:'flex', gap:'8px', flex:1, maxWidth:'350px', marginLeft:'20px' }}>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="🔍 Busca semântica com IA..." style={s.searchInput} onKeyDown={e=>e.key==='Enter'&&semanticSearch()} />
          <button style={s.searchBtn} onClick={semanticSearch} disabled={searching}>{searching ? '...' : '→'}</button>
          {search && <button style={s.clearBtn} onClick={()=>{setSearch('');load()}}>✕</button>}
        </div>
      </div>
      <div style={s.layout}>
        <div style={s.form}>
          <div style={s.formTitle}>{editing ? '✏️ Editar' : '+ Nova Nota'}</div>
          <div style={s.field}>
            <label style={s.label}>Título</label>
            <input type="text" placeholder="Título da nota..." value={form.title} onChange={e=>setForm(p=>({...p,title:e.target.value}))} style={s.input} />
          </div>
          <div style={s.field}>
            <label style={s.label}>Conteúdo *</label>
            <textarea placeholder="Escreva sua nota..." value={form.content} onChange={e=>setForm(p=>({...p,content:e.target.value}))} style={{...s.input, minHeight:'120px', resize:'vertical'}} />
          </div>
          <div style={s.field}>
            <label style={s.label}>Tags (vírgula)</label>
            <input type="text" placeholder="aula, programação, hex..." value={form.tags} onChange={e=>setForm(p=>({...p,tags:e.target.value}))} style={s.input} />
          </div>
          <div style={{display:'flex',gap:'6px'}}>
            <button style={s.btn} onClick={submit}>{editing ? 'Salvar' : 'Criar Nota'}</button>
            {editing && <button style={s.cancelBtn} onClick={()=>{setEditing(null);setForm({title:'',content:'',tags:''})}}>Cancelar</button>}
          </div>
          <div style={s.hint}>💬 Ou diga: "anote a aula de notação hexadecimal"</div>
        </div>
        <div style={s.grid}>
          {notes.length === 0 && <div style={s.empty}>Nenhuma nota. Crie uma ou peça à ARIA!</div>}
          {notes.map(n => (
            <div key={n.id} style={s.card}>
              <div style={s.cardTitle}>{n.title || 'Nota sem título'}</div>
              <div style={s.cardContent}>{n.content}</div>
              {n.tags?.length > 0 && (
                <div style={s.tagsRow}>{n.tags.map(t=><span key={t} style={s.tag}>#{t}</span>)}</div>
              )}
              <div style={s.cardFooter}>
                <span style={s.cardDate}>{dayjs(n.created_at).format('DD/MM/YYYY')}</span>
                <div style={{display:'flex',gap:'4px'}}>
                  <button style={s.cardBtn} onClick={()=>startEdit(n)}>✏️</button>
                  <button style={s.cardBtn} onClick={()=>del(n.id)}>🗑️</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

const s = {
  page:{flex:1,overflow:'auto',padding:'20px'},
  header:{display:'flex',alignItems:'center',marginBottom:'16px'},
  title:{fontFamily:'var(--mono)',fontWeight:800,fontSize:'18px'},
  searchInput:{flex:1,background:'var(--surface)',border:'1px solid var(--border2)',borderRadius:'8px',padding:'7px 12px',color:'var(--t1)',fontFamily:'var(--font)',fontSize:'12px',outline:'none'},
  searchBtn:{background:'var(--accent)',border:'none',borderRadius:'8px',color:'#fff',padding:'7px 12px',cursor:'pointer',fontWeight:700,fontFamily:'var(--font)'},
  clearBtn:{background:'var(--surface)',border:'1px solid var(--border2)',borderRadius:'8px',color:'var(--t3)',padding:'7px 10px',cursor:'pointer',fontFamily:'var(--font)'},
  layout:{display:'grid',gridTemplateColumns:'280px 1fr',gap:'16px'},
  form:{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:'12px',padding:'16px',height:'fit-content'},
  formTitle:{fontWeight:700,marginBottom:'12px',fontSize:'13px'},
  field:{marginBottom:'10px'},
  label:{display:'block',fontSize:'10px',fontWeight:700,color:'var(--t3)',textTransform:'uppercase',letterSpacing:'.8px',marginBottom:'4px'},
  input:{width:'100%',background:'var(--bg3)',border:'1px solid var(--border2)',borderRadius:'7px',padding:'8px 10px',color:'var(--t1)',fontFamily:'var(--font)',fontSize:'12px',outline:'none'},
  btn:{flex:1,background:'linear-gradient(135deg,#4f8ef7,#2a4fa8)',border:'none',borderRadius:'8px',color:'#fff',padding:'10px',fontWeight:700,cursor:'pointer',fontFamily:'var(--font)',fontSize:'13px'},
  cancelBtn:{background:'var(--surface2)',border:'1px solid var(--border2)',borderRadius:'8px',color:'var(--t2)',padding:'10px',cursor:'pointer',fontFamily:'var(--font)',fontSize:'12px'},
  hint:{fontSize:'10px',color:'var(--t3)',marginTop:'8px',textAlign:'center',fontStyle:'italic'},
  grid:{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(220px,1fr))',gap:'10px',alignContent:'start'},
  card:{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:'10px',padding:'14px',display:'flex',flexDirection:'column',gap:'6px',cursor:'default'},
  cardTitle:{fontWeight:700,fontSize:'13px'},
  cardContent:{fontSize:'11px',color:'var(--t2)',lineHeight:1.5,display:'-webkit-box',WebkitLineClamp:4,WebkitBoxOrient:'vertical',overflow:'hidden'},
  tagsRow:{display:'flex',gap:'4px',flexWrap:'wrap'},
  tag:{fontSize:'9px',padding:'2px 6px',background:'rgba(79,142,247,.12)',color:'var(--accent)',borderRadius:'4px',fontWeight:600},
  cardFooter:{display:'flex',justifyContent:'space-between',alignItems:'center',marginTop:'4px'},
  cardDate:{fontSize:'10px',color:'var(--t3)',fontFamily:'var(--mono)'},
  cardBtn:{background:'transparent',border:'none',cursor:'pointer',fontSize:'12px',opacity:.5,padding:'2px'},
  empty:{color:'var(--t3)',fontSize:'13px',textAlign:'center',padding:'40px',gridColumn:'1/-1'},
}
