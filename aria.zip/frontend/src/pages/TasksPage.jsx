import { useState, useEffect } from 'react'
import { tasksAPI } from '../services/api'
import toast from 'react-hot-toast'
import dayjs from 'dayjs'

export default function TasksPage() {
  const [tasks, setTasks] = useState([])
  const [form, setForm] = useState({ title:'', description:'', due_at:'', priority:'medium', tags:'' })

  const load = () => tasksAPI.list({ limit: 50 }).then(r => setTasks(r.data.items || [])).catch(() => {})
  useEffect(() => { load() }, [])

  const submit = async () => {
    if (!form.title) return toast.error('Título obrigatório')
    await tasksAPI.create({ ...form, tags: form.tags ? form.tags.split(',').map(t=>t.trim()) : [] })
    toast.success('Tarefa criada! ✅')
    setForm({ title:'', description:'', due_at:'', priority:'medium', tags:'' })
    load()
  }

  const done = async (id) => {
    await tasksAPI.done(id)
    toast.success('Concluída! 🎉')
    load()
  }

  const del = async (id) => { await tasksAPI.delete(id); load() }

  const pColor = { high:'#f05676', medium:'#f5a623', low:'#22d3a5' }

  return (
    <div style={s.page} className="fade-up">
      <div style={s.header}><div style={s.title}>✅ Tarefas</div></div>
      <div style={s.layout}>
        <div style={s.form}>
          <div style={s.formTitle}>+ Nova Tarefa</div>
          {[
            { label:'Título *', key:'title', type:'text', ph:'O que precisa fazer?' },
            { label:'Prazo', key:'due_at', type:'datetime-local' },
            { label:'Tags (vírgula)', key:'tags', type:'text', ph:'trabalho, pessoal...' },
          ].map(f => (
            <div key={f.key} style={s.field}>
              <label style={s.label}>{f.label}</label>
              <input type={f.type} placeholder={f.ph} value={form[f.key]} onChange={e=>setForm(p=>({...p,[f.key]:e.target.value}))} style={s.input} />
            </div>
          ))}
          <div style={s.field}>
            <label style={s.label}>Prioridade</label>
            <select value={form.priority} onChange={e=>setForm(p=>({...p,priority:e.target.value}))} style={s.input}>
              <option value="high">🔴 Alta</option>
              <option value="medium">🟡 Média</option>
              <option value="low">🟢 Baixa</option>
            </select>
          </div>
          <button style={s.btn} onClick={submit}>Criar Tarefa</button>
          <div style={s.hint}>💬 Ou diga: "me lembra de pagar a conta na sexta"</div>
        </div>
        <div style={s.list}>
          {tasks.length === 0 && <div style={s.empty}>Nenhuma tarefa. Ótimo!</div>}
          {tasks.map(t => (
            <div key={t.id} style={{ ...s.card, opacity: t.status==='done' ? .5 : 1, borderLeft: `3px solid ${pColor[t.priority]||'#4e6580'}` }}>
              <div style={{ flex:1 }}>
                <div style={{ display:'flex', alignItems:'center', gap:'8px', marginBottom:'4px' }}>
                  <span style={{ fontSize:'13px', fontWeight: t.status==='done' ? 400 : 700, textDecoration: t.status==='done' ? 'line-through' : 'none' }}>{t.title}</span>
                  <span style={{ fontSize:'9px', padding:'2px 6px', borderRadius:'4px', background:'var(--bg3)', color:'var(--t3)', fontWeight:700, textTransform:'uppercase' }}>{t.priority}</span>
                </div>
                {t.due_at && <div style={{ fontSize:'10px', color:'var(--t3)', fontFamily:'var(--mono)' }}>📅 {dayjs(t.due_at).format('DD/MM/YYYY HH:mm')}</div>}
                {t.tags?.length > 0 && <div style={{ marginTop:'4px', display:'flex', gap:'4px' }}>{t.tags.map(tag=><span key={tag} style={{ fontSize:'9px', padding:'1px 6px', borderRadius:'4px', background:'var(--surface2)', color:'var(--t2)' }}>#{tag}</span>)}</div>}
              </div>
              <div style={{ display:'flex', gap:'6px' }}>
                {t.status !== 'done' && <button style={s.actBtn} onClick={()=>done(t.id)}>✓</button>}
                <button style={{ ...s.actBtn, color:'#f05676' }} onClick={()=>del(t.id)}>✕</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

const s = {
  page:{flex:1,overflow:'auto',padding:'20px'},
  header:{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'16px'},
  title:{fontFamily:'var(--mono)',fontWeight:800,fontSize:'18px'},
  layout:{display:'grid',gridTemplateColumns:'300px 1fr',gap:'16px'},
  form:{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:'12px',padding:'16px'},
  formTitle:{fontWeight:700,marginBottom:'12px',fontSize:'13px'},
  field:{marginBottom:'10px'},
  label:{display:'block',fontSize:'10px',fontWeight:700,color:'var(--t3)',textTransform:'uppercase',letterSpacing:'.8px',marginBottom:'4px'},
  input:{width:'100%',background:'var(--bg3)',border:'1px solid var(--border2)',borderRadius:'7px',padding:'8px 10px',color:'var(--t1)',fontFamily:'var(--font)',fontSize:'12px',outline:'none'},
  btn:{width:'100%',background:'linear-gradient(135deg,#4f8ef7,#2a4fa8)',border:'none',borderRadius:'8px',color:'#fff',padding:'10px',fontWeight:700,cursor:'pointer',fontFamily:'var(--font)',fontSize:'13px',marginTop:'4px'},
  hint:{fontSize:'10px',color:'var(--t3)',marginTop:'8px',textAlign:'center',fontStyle:'italic'},
  list:{display:'flex',flexDirection:'column',gap:'8px'},
  card:{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:'10px',padding:'12px 16px',display:'flex',alignItems:'flex-start',justifyContent:'space-between',gap:'10px'},
  actBtn:{background:'var(--surface2)',border:'1px solid var(--border2)',borderRadius:'6px',padding:'5px 9px',cursor:'pointer',color:'var(--green)',fontWeight:700,fontSize:'13px',fontFamily:'var(--font)'},
  empty:{color:'var(--t3)',fontSize:'13px',textAlign:'center',padding:'40px'},
}
