import styled from './Sidebar.module.css'

const NAV = [
  { id: 'chat',      icon: '◈', label: 'Chat ARIA',   badge: null },
  { id: 'dashboard', icon: '⊞', label: 'Dashboard',   badge: null },
  { id: 'events',    icon: '◷', label: 'Agenda',       badge: null },
  { id: 'tasks',     icon: '◎', label: 'Tarefas',      badge: null },
  { id: 'notes',     icon: '◱', label: 'Notas',        badge: null },
  { id: 'finance',   icon: '◈', label: 'Financeiro',   badge: null },
  { id: 'health',    icon: '◉', label: 'Saúde',        badge: null },
]

export default function Sidebar({ current, onNavigate }) {
  return (
    <aside style={styles.sidebar}>
      {/* Logo */}
      <div style={styles.logo}>
        <div style={styles.logoMark}>A</div>
        <div>
          <div style={styles.logoName}>ARIA</div>
          <div style={styles.logoSub}>Gemini · Telegram · n8n</div>
        </div>
      </div>

      {/* Nav */}
      <nav style={styles.nav}>
        <div style={styles.sectionLabel}>MENU</div>
        {NAV.map(item => (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            style={{
              ...styles.navItem,
              ...(current === item.id ? styles.navActive : {}),
            }}
          >
            <span style={styles.navIcon}>{item.icon}</span>
            <span style={styles.navLabel}>{item.label}</span>
            {item.badge && <span style={styles.badge}>{item.badge}</span>}
          </button>
        ))}
      </nav>

      {/* Bot status */}
      <div style={styles.botStatus}>
        <div style={styles.botDot} />
        <div>
          <div style={styles.botName}>ARIA Bot</div>
          <div style={styles.botSub}>Online · Telegram</div>
        </div>
      </div>
    </aside>
  )
}

const styles = {
  sidebar: {
    width: '220px',
    minWidth: '220px',
    height: '100vh',
    background: 'var(--bg1)',
    borderRight: '1px solid var(--border)',
    display: 'flex',
    flexDirection: 'column',
    position: 'relative',
    zIndex: 2,
  },
  logo: {
    padding: '18px 16px 14px',
    borderBottom: '1px solid var(--border)',
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
  },
  logoMark: {
    width: '34px', height: '34px',
    borderRadius: '9px',
    background: 'linear-gradient(135deg, #4f8ef7, #9b72f7)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontWeight: 800, fontSize: '14px', color: '#fff',
    boxShadow: '0 0 20px rgba(79,142,247,0.3)',
    flexShrink: 0,
  },
  logoName: {
    fontWeight: 800, fontSize: '15px', letterSpacing: '1.5px',
    fontFamily: 'var(--mono)',
  },
  logoSub: {
    fontSize: '9px', color: 'var(--t3)', marginTop: '1px',
    fontFamily: 'var(--mono)', letterSpacing: '.5px',
  },
  nav: { flex: 1, padding: '8px 8px', display: 'flex', flexDirection: 'column', gap: '1px' },
  sectionLabel: {
    fontSize: '9px', fontWeight: 700, color: 'var(--t3)',
    letterSpacing: '1.5px', padding: '8px 8px 4px',
    textTransform: 'uppercase',
  },
  navItem: {
    display: 'flex', alignItems: 'center', gap: '9px',
    padding: '9px 10px', borderRadius: '8px', cursor: 'pointer',
    border: 'none', background: 'transparent', color: 'var(--t2)',
    fontSize: '12.5px', fontWeight: 500, width: '100%', textAlign: 'left',
    fontFamily: 'var(--font)', transition: 'all .15s',
  },
  navActive: {
    background: 'linear-gradient(135deg, rgba(79,142,247,.18), rgba(155,114,247,.1))',
    color: '#7ab4fa',
    border: '1px solid rgba(79,142,247,.2)',
  },
  navIcon: { fontSize: '14px', width: '16px', textAlign: 'center', flexShrink: 0 },
  navLabel: { flex: 1 },
  badge: {
    background: '#3a6cc4', color: '#fff',
    fontSize: '9px', fontWeight: 700,
    padding: '1px 5px', borderRadius: '8px',
  },
  botStatus: {
    margin: '12px', padding: '10px 12px',
    background: 'var(--surface)', borderRadius: '10px',
    border: '1px solid var(--border)',
    display: 'flex', alignItems: 'center', gap: '9px',
  },
  botDot: {
    width: '8px', height: '8px', borderRadius: '50%',
    background: 'var(--green)',
    boxShadow: '0 0 0 0 rgba(34,211,165,0.4)',
    animation: 'pulse 2s infinite', flexShrink: 0,
  },
  botName: { fontSize: '12px', fontWeight: 700 },
  botSub: { fontSize: '10px', color: 'var(--t3)', marginTop: '1px' },
}
