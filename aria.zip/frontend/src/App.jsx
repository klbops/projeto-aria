import { useState } from 'react'
import Sidebar from './components/Sidebar'
import ChatPage from './pages/ChatPage'
import DashboardPage from './pages/DashboardPage'
import EventsPage from './pages/EventsPage'
import TasksPage from './pages/TasksPage'
import NotesPage from './pages/NotesPage'
import FinancePage from './pages/FinancePage'
import HealthPage from './pages/HealthPage'
import { Toaster } from 'react-hot-toast'

export default function App() {
  const [page, setPage] = useState('chat')

  const pages = {
    dashboard: <DashboardPage onNavigate={setPage} />,
    chat:      <ChatPage />,
    events:    <EventsPage />,
    tasks:     <TasksPage />,
    notes:     <NotesPage />,
    finance:   <FinancePage />,
    health:    <HealthPage />,
  }

  return (
    <>
      <Toaster
        position="bottom-right"
        toastOptions={{
          style: {
            background: '#162030',
            color: '#e1e8f0',
            border: '1px solid #243452',
            fontFamily: 'Plus Jakarta Sans, sans-serif',
            fontSize: '13px',
          },
        }}
      />
      <Sidebar current={page} onNavigate={setPage} />
      <main style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', position: 'relative', zIndex: 1 }}>
        {pages[page] || pages.chat}
      </main>
    </>
  )
}
