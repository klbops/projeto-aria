import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:3001',
  timeout: 30000,
})

// ── Chat ──────────────────────────────────────────────────────────────────────
export const chatAPI = {
  send:       (message, sessionId) => api.post('/api/chat', { message, sessionId }),
  history:    (limit = 50)        => api.get(`/api/chat/history?limit=${limit}`),
  clearHistory: ()                 => api.delete('/api/chat/history'),
}

// ── Events ────────────────────────────────────────────────────────────────────
export const eventsAPI = {
  list:     (params)  => api.get('/api/events', { params }),
  upcoming: (limit=5) => api.get(`/api/events/upcoming?limit=${limit}`),
  today:    ()        => api.get('/api/events/today'),
  create:   (data)    => api.post('/api/events', data),
  update:   (id, data)=> api.put(`/api/events/${id}`, data),
  delete:   (id)      => api.delete(`/api/events/${id}`),
}

// ── Tasks ─────────────────────────────────────────────────────────────────────
export const tasksAPI = {
  list:    (params)   => api.get('/api/tasks', { params }),
  pending: (limit=20) => api.get(`/api/tasks/pending?limit=${limit}`),
  create:  (data)     => api.post('/api/tasks', data),
  update:  (id, data) => api.put(`/api/tasks/${id}`, data),
  done:    (id)       => api.patch(`/api/tasks/${id}/done`),
  delete:  (id)       => api.delete(`/api/tasks/${id}`),
}

// ── Notes ─────────────────────────────────────────────────────────────────────
export const notesAPI = {
  list:   (params)   => api.get('/api/notes', { params }),
  search: (q)        => api.get(`/api/notes/search?q=${encodeURIComponent(q)}`),
  create: (data)     => api.post('/api/notes', data),
  update: (id, data) => api.put(`/api/notes/${id}`, data),
  delete: (id)       => api.delete(`/api/notes/${id}`),
}

// ── Finance ───────────────────────────────────────────────────────────────────
export const financeAPI = {
  list:    (params)  => api.get('/api/finance', { params }),
  bills:   ()        => api.get('/api/finance/bills'),
  create:  (data)    => api.post('/api/finance', data),
  pay:     (id)      => api.patch(`/api/finance/${id}/pay`),
  delete:  (id)      => api.delete(`/api/finance/${id}`),
}

// ── Health ────────────────────────────────────────────────────────────────────
export const healthAPI = {
  today:  ()     => api.get('/api/health/today'),
  logs:   ()     => api.get('/api/health/logs'),
  log:    (data) => api.post('/api/health/log', data),
}

// ── Weather ───────────────────────────────────────────────────────────────────
export const weatherAPI = {
  current:  () => api.get('/api/weather/current'),
  forecast: () => api.get('/api/weather/forecast'),
}

// ── Contacts ──────────────────────────────────────────────────────────────────
export const contactsAPI = {
  list:   ()         => api.get('/api/contacts'),
  create: (data)     => api.post('/api/contacts', data),
  update: (id, data) => api.put(`/api/contacts/${id}`, data),
  delete: (id)       => api.delete(`/api/contacts/${id}`),
}

export default api
